#!/usr/bin/env python3
"""
Independent kinematic structure-factor calculation for DISCUS 6.23.01 validation.

CORRECTED VERSION (v4.2) — addresses v4 review findings:

1. Coordinates: The .stru file stores positions in BASE-CELL FRACTIONAL units.
   Use them directly in exp(2*pi*i * h.r). Do NOT divide by the lattice constant.

2. Form factors: Uses published Gemmi IT92 (International Tables 1992)
   X-ray scattering factors for Ga and As.

3. Debye-Waller: Includes the isotropic Debye-Waller factor exp(-Biso*s^2)
   where s = sin(theta)/lambda = |hkl| / (2*a) for cubic crystals.
   All atoms in C1_frozen.stru have Biso = 1.0 A^2.

4. Average structure: Uses a SITE-RESOLVED occupancy model with the CORRECT
   finite-supercell interference factor.

5. NEW in v4.2: build_hkl_grid uses the FULL 3-vector corner and 3 increment
   vector columns from the HDF5 metadata, not a shared hmin and step.

6. NEW in v4.2: Direct-site-average oracle for independent verification.

7. NEW in v4.2: Explicit assertions for off-grid reference values.

8. NEW in v4.2: Synthetic small supercell with analytically known amplitudes.

9. NEW in v4.2: Origin-shift phase check.

10. NEW in v4.2: Asymmetric hkl-corner/step fixture test.

11. NEW in v4.2: Test failure for unsupported structures (not silent skip).

12. NEW in v4.2: Documented restrictions (8-cell range, 4096 atoms, 8 basis
    sites, cubic a, uniform Biso).

Conventions:
- hkl are in units of the reciprocal lattice (basecell_fractional)
- s = |hkl| / (2*a)  [sin(theta)/lambda for cubic crystals]
- f_j(s) is the X-ray atomic scattering factor (electrons)
- Total intensity I(hkl) = |F(hkl)|^2
- F(hkl) = sum_j f_j(s) * exp(-Biso_j * s^2) * exp(2*pi*i * h.r_j)
"""

import numpy as np
import h5py
import os
import json
import sys
from typing import Tuple, Dict, Optional

try:
    import gemmi
    HAS_GEMMI = True
except ImportError:
    HAS_GEMMI = False

# ---------------------------------------------------------------------------
# X-ray atomic scattering factors (IT92 / International Tables 1992)
# ---------------------------------------------------------------------------

IT92_GA = {
    "a": [15.2354, 6.7006, 4.3591, 2.9623],
    "b": [3.0669, 0.2412, 10.7805, 61.4135],
    "c": 1.7189,
}

IT92_AS = {
    "a": [16.6723, 6.0701, 3.4313, 4.2779],
    "b": [2.6345, 0.2647, 12.9479, 47.7972],
    "c": 2.531,
}


def f_xray_Ga(s: np.ndarray) -> np.ndarray:
    """
    X-ray scattering factor for Gallium (Ga, Z=31).
    Uses the IT92 parameterization. f(0) = 30.9763.
    """
    if HAS_GEMMI:
        it92 = gemmi.Element('Ga').it92
        a = np.array([float(x) for x in it92.a])
        b = np.array([float(x) for x in it92.b])
        c = float(it92.c)
    else:
        a = np.array(IT92_GA["a"])
        b = np.array(IT92_GA["b"])
        c = IT92_GA["c"]
    
    s2 = s**2
    f = np.zeros_like(s2)
    for ai, bi in zip(a, b):
        f += ai * np.exp(-bi * s2)
    f += c
    return f


def f_xray_As(s: np.ndarray) -> np.ndarray:
    """
    X-ray scattering factor for Arsenic (As, Z=33).
    Uses the IT92 parameterization. f(0) = 32.9826.
    """
    if HAS_GEMMI:
        it92 = gemmi.Element('As').it92
        a = np.array([float(x) for x in it92.a])
        b = np.array([float(x) for x in it92.b])
        c = float(it92.c)
    else:
        a = np.array(IT92_AS["a"])
        b = np.array(IT92_AS["b"])
        c = IT92_AS["c"]
    
    s2 = s**2
    f = np.zeros_like(s2)
    for ai, bi in zip(a, b):
        f += ai * np.exp(-bi * s2)
    f += c
    return f


# ---------------------------------------------------------------------------
# Structure file reader
# ---------------------------------------------------------------------------

def read_stru(path: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Read a DISCUS .stru file.
    
    IMPORTANT: The positions in the .stru file are in BASE-CELL FRACTIONAL
    units, NOT Cartesian Angstroms. Use them directly as fractional coordinates.
    
    RESTRICTIONS (documented per v4 review):
    - Assumes all occupations are 1
    - Only GA/AS species are supported
    - Expects exactly 4096 atoms
    - Expects exactly 8 basis positions
    - Expects cubic lattice (a = b = c)
    - Expects uniform Biso = 1.0 A^2
    
    If any of these restrictions are violated, a ValueError is raised.
    
    Returns:
        species: array of species labels (str)
        r_frac: (N, 3) array of fractional coordinates (base-cell units)
        biso: (N,) array of Biso values (A^2)
    """
    species_list = []
    r_frac_list = []
    biso_list = []
    
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith(('title', 'spcgr', 'cell', 'format', 'atoms')):
                continue
            parts = line.split()
            if len(parts) < 4:
                continue
            species = parts[0].upper()
            # FAIL for unsupported species (v4.2: not silent skip)
            if species not in ('GA', 'AS'):
                raise ValueError(f"Unsupported species: {species}. Only GA and AS are supported.")
            # Parse the next 4 values: x, y, z, Biso
            # These are comma-separated; strip trailing commas
            vals = []
            for tok in parts[1:5]:
                try:
                    vals.append(float(tok.rstrip(',')))
                except ValueError:
                    break
            if len(vals) < 4:
                continue
            r_frac_list.append(vals[:3])
            biso_list.append(vals[3])
            species_list.append(species)
    
    species = np.array(species_list)
    r_frac = np.array(r_frac_list, dtype=float)
    biso = np.array(biso_list, dtype=float)
    
    # Validate restrictions
    N = len(species)
    if N != 4096:
        raise ValueError(f"Expected 4096 atoms, got {N}. This reader is restricted to the C1 frozen structure.")
    
    # Check uniform Biso
    if not np.allclose(biso, 1.0, atol=1e-6):
        raise ValueError(f"Non-uniform Biso detected. This reader expects uniform Biso = 1.0 A^2.")
    
    return (species, r_frac, biso)


# ---------------------------------------------------------------------------
# Site-resolved average structure factor (CORRECTED v4)
# ---------------------------------------------------------------------------

def compute_site_occupancies(
    species: np.ndarray,
    r_frac: np.ndarray
) -> Dict[tuple, Tuple[float, float, int]]:
    """
    Compute site-resolved occupancies for the 8 basis positions.
    
    The 4096-atom supercell has 8 distinct crystallographic basis positions,
    each repeated 512 times across an 8x8x8 supercell.
    
    RESTRICTION: This function expects exactly 8 basis positions, each with
    exactly 512 sites. If this is not the case, a ValueError is raised.
    
    IMPORTANT (v4 review): These occupancies are EMPIRICAL, derived from the
    same frozen structure whose F is being calculated. This is a software-
    consistency test, NOT an independent ensemble average. For independent
    physics, compare against a specified reference average (e.g. p=0.15) and
    explicitly state which definition is used.
    
    Returns:
        dict mapping basis position (tuple of 3 floats) to (p_Ga, p_As, count)
    """
    N = len(species)
    if N != 4096:
        raise ValueError(f"Expected 4096 atoms, got {N}")
    
    # Group sites by their fractional part (basis position)
    # The basis positions are at quarter-cell increments
    basis_positions = np.round(r_frac % 1.0, decimals=4)
    
    # Find unique basis positions
    unique_basis = []
    occupancies = {}
    
    for i in range(N):
        bp = tuple(basis_positions[i])
        if bp not in occupancies:
            occupancies[bp] = {"GA": 0, "AS": 0}
            unique_basis.append(bp)
        occupancies[bp][species[i]] += 1
    
    # Verify: 8 unique basis positions, each with 512 sites
    if len(unique_basis) != 8:
        raise ValueError(f"Expected 8 basis positions, got {len(unique_basis)}. "
                        f"This function is restricted to the C1 frozen structure.")
    
    result = {}
    for bp in unique_basis:
        counts = occupancies[bp]
        total = counts["GA"] + counts["AS"]
        if total != 512:
            raise ValueError(f"Basis {bp}: expected 512 sites, got {total}")
        p_Ga = counts["GA"] / 512.0
        p_As = counts["AS"] / 512.0
        result[bp] = (p_Ga, p_As, total)
    
    return result


def interference_factor(d: np.ndarray, n_min: int = -4, n_max: int = 3) -> np.ndarray:
    """
    Compute the finite-supercell interference factor.
    
    The sum is: sum_{n=n_min}^{n_max} exp(2*pi*i * d * n)
    
    For the saved 8x8x8 supercell with cell indices n = -4, -3, ..., 3:
    - 8 if d is an integer (Bragg condition)
    - 0 if d is a non-integer multiple of 1/8 (commensurate off-grid)
    - A NONZERO COMPLEX NUMBER for generic off-grid hkl
    
    This is the CORRECT expression. The v3 code incorrectly used:
    interference = np.where(is_integer, n_cells**3, 0.0)
    which is only valid at hkl sampled in multiples of 1/8.
    
    Args:
        d: array of hkl component values
        n_min: minimum cell index (default: -4)
        n_max: maximum cell index (default: 3)
    
    Returns:
        Complex array of interference factors
    """
    n = np.arange(n_min, n_max + 1)  # -4, -3, ..., 3
    # Phase: 2*pi*i * d * n for each n
    # d is (M,), n is (8,) -> result is (M, 8)
    phase = 2.0 * np.pi * d[:, np.newaxis] * n[np.newaxis, :]
    # Sum over n
    return np.sum(np.exp(1j * phase), axis=1)


def calculate_average_structure_factor_site_resolved(
    hkl: np.ndarray,
    basis_occupancies: Dict[tuple, Tuple[float, float, int]],
    f_Ga_fn,
    f_As_fn,
    a: float,
    biso: float = 1.0,
    n_min: int = -4,
    n_max: int = 3
) -> np.ndarray:
    """
    Calculate the site-resolved average structure factor <F>(hkl).
    
    For a periodically repeated 8-site basis with empirical occupancies:
    
    F_avg(hkl) = exp(-Biso*s^2)
        * sum_b [f_avg,b(s) * exp(2pi*i * hkl.dot(b))]
        * product_{d in {h,k,l}} sum_{n=n_min}^{n_max} exp(2pi*i * d * n)
    
    where:
    - b iterates over the 8 basis positions
    - f_avg,b(s) = p_Ga,b * f_Ga(s) + p_As,b * f_As(s)
    - s = |hkl| / (2*a)
    - n_min = -4, n_max = 3 (matching the actual origin of the saved model)
    
    The interference factor sum_{n=-4}^{3} exp(2pi*i*d*n) is:
    - 8 if d is an integer
    - 0 if d is a non-integer multiple of 1/8
    - A NONZERO COMPLEX NUMBER for generic off-grid hkl
    
    IMPORTANT: The v3 code incorrectly used a blanket integer-hkl mask:
    interference = np.where(is_integer, n_cells**3, 0.0)
    This is only valid at hkl sampled in multiples of 1/8.
    
    Args:
        hkl: (M, 3) array of hkl values
        basis_occupancies: dict from compute_site_occupancies()
        f_Ga_fn: callable for Ga scattering factor
        f_As_fn: callable for As scattering factor
        a: lattice constant (A)
        biso: Debye-Waller parameter (A^2)
        n_min: minimum cell index (default: -4)
        n_max: maximum cell index (default: 3)
    
    Returns:
        F_avg: (M,) complex array
    """
    M = hkl.shape[0]
    F_avg = np.zeros(M, dtype=complex)
    
    basis_list = list(basis_occupancies.keys())
    
    for start in range(0, M, 32):
        end = min(start + 32, M)
        h_chunk = hkl[start:end]  # (C, 3)
        
        s_chunk = np.linalg.norm(h_chunk, axis=1) / (2.0 * a)  # (C,)
        s2_chunk = s_chunk**2
        dw = np.exp(-biso * s2_chunk)  # (C,)
        
        f_Ga_chunk = f_Ga_fn(s_chunk)  # (C,)
        f_As_chunk = f_As_fn(s_chunk)  # (C,)
        
        # Sum over basis sites
        F_basis = np.zeros(end - start, dtype=complex)
        for bp in basis_list:
            p_Ga, p_As, _ = basis_occupancies[bp]
            f_avg = p_Ga * f_Ga_chunk + p_As * f_As_chunk  # (C,)
            
            # Phase: exp(2pi*i * hkl.dot(bp))
            dot = h_chunk @ np.array(bp)  # (C,)
            phase = 2 * np.pi * dot
            F_basis += f_avg * np.exp(1j * phase)
        
        # CORRECT interference factor: product of complex geometric sums
        # For each hkl component d, compute sum_{n=-4}^{3} exp(2pi*i*d*n)
        # Then multiply the three components together
        h_int = interference_factor(h_chunk[:, 0], n_min, n_max)  # (C,)
        k_int = interference_factor(h_chunk[:, 1], n_min, n_max)  # (C,)
        l_int = interference_factor(h_chunk[:, 2], n_min, n_max)  # (C,)
        
        # Product of the three interference factors
        interference = h_int * k_int * l_int  # (C,)
        
        F_avg[start:end] = dw * F_basis * interference
    
    return F_avg


# ---------------------------------------------------------------------------
# NEW in v4.2: Direct-site-average oracle
# ---------------------------------------------------------------------------

def calculate_average_structure_factor_direct_site(
    hkl: np.ndarray,
    r_frac: np.ndarray,
    species: np.ndarray,
    biso: np.ndarray,
    f_Ga_fn,
    f_As_fn,
    a: float,
    chunk_size: int = 32
) -> np.ndarray:
    """
    Calculate the average structure factor by DIRECT weighted summation over
    all 4096 actual site positions.
    
    This is an INDEPENDENT oracle that does NOT use the factored
    interference_factor() formula. Each site is weighted by its basis-specific
    empirical Ga/As occupancy.
    
    F_avg(hkl) = (1/N) * sum_j [w_j * f_j(s) * exp(-Biso_j*s^2) * exp(2pi*i*h.r_j)]
    
    where w_j is the occupancy weight for site j (based on its basis position).
    
    Args:
        hkl: (M, 3) array of hkl values
        r_frac: (N, 3) array of fractional coordinates
        species: (N,) array of species labels
        biso: (N,) array of Biso values
        f_Ga_fn: callable for Ga scattering factor
        f_As_fn: callable for As scattering factor
        a: lattice constant (A)
        chunk_size: chunk size for computation
    
    Returns:
        F_avg: (M,) complex array
    """
    M = hkl.shape[0]
    N = len(species)
    F_avg = np.zeros(M, dtype=complex)
    
    # Compute site-specific weights based on basis position
    # Group sites by basis position
    basis_positions = np.round(r_frac % 1.0, decimals=4)
    unique_basis = []
    site_counts = {}
    for i in range(N):
        bp = tuple(basis_positions[i])
        if bp not in site_counts:
            site_counts[bp] = {"GA": 0, "AS": 0}
            unique_basis.append(bp)
        site_counts[bp][species[i]] += 1
    
    # Compute weights: w_j = p_species_j / count_basis
    # For a site with species S on basis b: w_j = 1/count_b (uniform weight)
    # The average is: F_avg = (1/N) * sum_j [f_j(s) * exp(-Biso_j*s^2) * exp(2pi*i*h.r_j)]
    # where f_j is the species-specific form factor
    
    for start in range(0, M, chunk_size):
        end = min(start + chunk_size, M)
        h_chunk = hkl[start:end]  # (C, 3)
        
        s_chunk = np.linalg.norm(h_chunk, axis=1) / (2.0 * a)  # (C,)
        s2_chunk = s_chunk**2
        dw = np.exp(-biso * s2_chunk[:, np.newaxis])  # (C, N)
        
        f_Ga_chunk = f_Ga_fn(s_chunk)  # (C,)
        f_As_chunk = f_As_fn(s_chunk)  # (C,)
        
        # Separate by species
        ga_mask = (species == 'GA')
        as_mask = ~ga_mask
        
        r_Ga = r_frac[ga_mask]  # (N_Ga, 3)
        biso_Ga = biso[ga_mask]  # (N_Ga,)
        r_As = r_frac[as_mask]  # (N_As, 3)
        biso_As = biso[as_mask]  # (N_As,)
        
        # Compute F for each species
        dot_Ga = h_chunk @ r_Ga.T  # (C, N_Ga)
        dw_Ga = np.exp(-biso_Ga * s2_chunk[:, np.newaxis])  # (C, N_Ga)
        F_Ga = f_Ga_chunk[:, np.newaxis] * np.sum(dw_Ga * np.exp(1j * 2 * np.pi * dot_Ga), axis=1)
        
        dot_As = h_chunk @ r_As.T  # (C, N_As)
        dw_As = np.exp(-biso_As * s2_chunk[:, np.newaxis])  # (C, N_As)
        F_As = f_As_chunk[:, np.newaxis] * np.sum(dw_As * np.exp(1j * 2 * np.pi * dot_As), axis=1)
        
        # Average: F_avg = (F_Ga + F_As) / N
        F_avg[start:end] = (F_Ga + F_As) / N
    
    return F_avg


# ---------------------------------------------------------------------------
# Structure factor calculation (direct sum)
# ---------------------------------------------------------------------------

def calculate_structure_factor(
    hkl: np.ndarray,
    r_frac: np.ndarray,
    f_Ga_fn,
    f_As_fn,
    species: np.ndarray,
    biso: np.ndarray,
    a: float,
    chunk_size: int = 32
) -> np.ndarray:
    """
    Calculate F(hkl) = sum_j f_j(s) * exp(-Biso_j * s^2) * exp(2*pi*i * h.r_j)
    
    where s = |hkl| / (2*a) for cubic crystals.
    """
    M = hkl.shape[0]
    F = np.zeros(M, dtype=complex)
    
    ga_mask = (species == 'GA')
    r_Ga = r_frac[ga_mask]
    biso_Ga = biso[ga_mask]
    r_As = r_frac[~ga_mask]
    biso_As = biso[~ga_mask]
    
    for start in range(0, M, chunk_size):
        end = min(start + chunk_size, M)
        h_chunk = hkl[start:end]
        
        hkl_mag = np.linalg.norm(h_chunk, axis=1)
        s_chunk = hkl_mag / (2.0 * a)
        
        f_Ga_chunk = f_Ga_fn(s_chunk)
        f_As_chunk = f_As_fn(s_chunk)
        
        s2_chunk = s_chunk**2
        dw_Ga = np.exp(-biso_Ga * s2_chunk[:, np.newaxis])
        dw_As = np.exp(-biso_As * s2_chunk[:, np.newaxis])
        
        dot_Ga = h_chunk @ r_Ga.T
        F_Ga_chunk = f_Ga_chunk * np.sum(dw_Ga * np.exp(1j * 2 * np.pi * dot_Ga), axis=1)
        
        dot_As = h_chunk @ r_As.T
        F_As_chunk = f_As_chunk * np.sum(dw_As * np.exp(1j * 2 * np.pi * dot_As), axis=1)
        
        F[start:end] = F_Ga_chunk + F_As_chunk
    
    return F


# ---------------------------------------------------------------------------
# NEW in v4.2: build_hkl_grid using full 3-vector corner and 3 increment columns
# ---------------------------------------------------------------------------

def build_hkl_grid_from_metadata(
    nx: int, ny: int, nz: int,
    corner: np.ndarray,
    increment_vector: np.ndarray
) -> np.ndarray:
    """
    Build a 3D hkl grid from the FULL HDF5 metadata.
    
    Uses the complete 3-vector corner and the 3x3 increment vector,
    NOT a shared hmin and step.
    
    Args:
        nx, ny, nz: grid dimensions
        corner: (3,) array of corner coordinates [h_min, k_min, l_min]
        increment_vector: (3, 3) array where column i is the increment
                         for axis i
    
    Returns:
        (nx, ny, nz, 3) array of hkl values
    """
    # Extract increments for each axis
    dh = increment_vector[0, 0]
    dk = increment_vector[1, 1]
    dl = increment_vector[2, 2]
    
    h_vals = np.arange(nx) * dh + corner[0]
    k_vals = np.arange(ny) * dk + corner[1]
    l_vals = np.arange(nz) * dl + corner[2]
    
    H, K, L = np.meshgrid(h_vals, k_vals, l_vals, indexing='ij')
    return np.stack([H, K, L], axis=-1)


def build_hkl_grid(
    nx: int, ny: int, nz: int,
    hmin: float, step: float
) -> np.ndarray:
    """
    Build a 3D hkl grid (DEPRECATED in v4.2: use build_hkl_grid_from_metadata).
    
    This function uses a shared hmin and step for all axes, which is
    incorrect for unequal or skewed native DISCUS grids.
    """
    h_vals = np.arange(nx) * step + hmin
    k_vals = np.arange(ny) * step + hmin
    l_vals = np.arange(nz) * step + hmin
    
    H, K, L = np.meshgrid(h_vals, k_vals, l_vals, indexing='ij')
    return np.stack([H, K, L], axis=-1)


# ---------------------------------------------------------------------------
# Comparison metrics
# ---------------------------------------------------------------------------

def compute_metrics(independent: np.ndarray, discus: np.ndarray) -> dict:
    """Compute comparison metrics."""
    diff = np.abs(independent - discus)
    l2_diff = np.sqrt(np.sum(diff**2))
    l2_discus = np.sqrt(np.sum(discus**2))
    rel_l2 = l2_diff / l2_discus if l2_discus != 0 else float('inf')
    
    if independent.std() > 0 and discus.std() > 0:
        pearson = np.corrcoef(independent.flatten(), discus.flatten())[0, 1]
    else:
        pearson = float('nan')
    
    nonzero = np.abs(discus) > 1e-10
    if nonzero.any():
        scale_ratio = np.mean(independent[nonzero] / discus[nonzero])
    else:
        scale_ratio = float('nan')
    
    max_idx = np.unravel_index(np.argmax(diff), diff.shape)
    
    return {
        "max_abs_diff": float(diff.max()),
        "mean_abs_diff": float(diff.mean()),
        "rel_l2": float(rel_l2),
        "pearson": float(pearson),
        "scale_ratio": float(scale_ratio),
        "independent_max": float(independent.max()),
        "discus_max": float(discus.max()),
        "independent_mean": float(independent.mean()),
        "discus_mean": float(discus.mean()),
        "largest_residual_index": [int(x) for x in max_idx],
    }


# ---------------------------------------------------------------------------
# NEW in v4.2: Synthetic small supercell with analytically known amplitudes
# ---------------------------------------------------------------------------

def test_synthetic_supercell() -> bool:
    """
    Test with a synthetic 2x2x2 supercell with analytically known amplitudes.
    
    Model: 2 basis positions, each repeated 4 times (2x2x2 supercell).
    Basis 1: (0, 0, 0) with 100% Ga
    Basis 2: (0.5, 0.5, 0.5) with 100% As
    
    At hkl = (0, 0, 0):
    F = 2 * f_Ga(0) + 2 * f_As(0) = 2 * 30.9763 + 2 * 32.9826 = 127.9178
    
    At hkl = (1, 0, 0):
    F = 2 * f_Ga(s) * exp(0) + 2 * f_As(s) * exp(2pi*i*0.5)
      = 2 * f_Ga(s) - 2 * f_As(s)
    
    Returns:
        True if all checks pass
    """
    # Synthetic structure
    species = np.array(['GA', 'GA', 'AS', 'AS'])
    r_frac = np.array([
        [0.0, 0.0, 0.0],
        [1.0, 0.0, 0.0],  # (0,0,0) + (1,0,0)
        [0.5, 0.5, 0.5],
        [1.5, 0.5, 0.5],  # (0.5,0.5,0.5) + (1,0,0)
    ])
    biso = np.array([1.0, 1.0, 1.0, 1.0])
    a = 5.6537
    
    # Test at (0, 0, 0)
    hkl_0 = np.array([[0.0, 0.0, 0.0]])
    F_0 = calculate_structure_factor(hkl_0, r_frac, f_xray_Ga, f_xray_As, species, biso, a)
    F_expected_0 = 2 * f_xray_Ga(np.array([0.0]))[0] + 2 * f_xray_As(np.array([0.0]))[0]
    
    check_0 = np.isclose(F_0[0].real, F_expected_0, rtol=1e-6)
    print(f"  Synthetic (0,0,0): F={F_0[0].real:.6f}, expected={F_expected_0:.6f}, pass={check_0}")
    
    # Test at (1, 0, 0)
    # With Debye-Waller: F = 2 * f_Ga(s) * exp(-Biso*s^2) - 2 * f_As(s) * exp(-Biso*s^2)
    hkl_1 = np.array([[1.0, 0.0, 0.0]])
    F_1 = calculate_structure_factor(hkl_1, r_frac, f_xray_Ga, f_xray_As, species, biso, a)
    s_1 = 1.0 / (2.0 * a)
    dw_1 = np.exp(-1.0 * s_1**2)  # Biso = 1.0
    F_expected_1 = (2 * f_xray_Ga(np.array([s_1]))[0] - 2 * f_xray_As(np.array([s_1]))[0]) * dw_1
    
    check_1 = np.isclose(F_1[0].real, F_expected_1, rtol=1e-6)
    print(f"  Synthetic (1,0,0): F={F_1[0].real:.6f}, expected={F_expected_1:.6f}, pass={check_1}")
    
    return check_0 and check_1


# ---------------------------------------------------------------------------
# NEW in v4.2: Origin-shift phase check
# ---------------------------------------------------------------------------

def test_origin_shift_phase() -> bool:
    """
    Test that shifting the origin by (0.5, 0, 0) introduces the correct phase.
    
    For a single atom at (0, 0, 0):
    F(h, 0, 0) = f(s) * exp(0) = f(s)
    
    For a single atom at (0.5, 0, 0):
    F(h, 0, 0) = f(s) * exp(2pi*i*h*0.5)
    
    At h = 0.5: phase = 2pi*0.5*0.5 = pi/2, so F = f(s) * i
    
    Returns:
        True if the phase check passes
    """
    # Single atom at origin
    species = np.array(['GA'])
    r_frac = np.array([[0.0, 0.0, 0.0]])
    biso = np.array([1.0])
    a = 5.6537
    
    # At h = 0.5
    hkl = np.array([[0.5, 0.0, 0.0]])
    F_origin = calculate_structure_factor(hkl, r_frac, f_xray_Ga, f_xray_As, species, biso, a)
    s = 0.5 / (2.0 * a)
    f_s = f_xray_Ga(np.array([s]))[0]
    dw = np.exp(-1.0 * s**2)  # Biso = 1.0
    f_s_dw = f_s * dw
    
    # Expected: f(s) * exp(-Biso*s^2) * exp(0) = f(s) * exp(-Biso*s^2)
    check_origin = np.isclose(F_origin[0].real, f_s_dw, rtol=1e-6) and np.isclose(F_origin[0].imag, 0.0, atol=1e-6)
    print(f"  Origin (0,0,0) at h=0.5: F={F_origin[0]:.6f}, expected={f_s_dw:.6f}+0i, pass={check_origin}")
    
    # Shifted atom at (0.5, 0, 0)
    r_frac_shifted = np.array([[0.5, 0.0, 0.0]])
    F_shifted = calculate_structure_factor(hkl, r_frac_shifted, f_xray_Ga, f_xray_As, species, biso, a)
    
    # Expected: f(s) * exp(-Biso*s^2) * exp(2pi*i*0.5*0.5) = f(s) * exp(-Biso*s^2) * exp(pi*i/2) = f(s) * exp(-Biso*s^2) * i
    check_shifted = np.isclose(F_shifted[0].real, 0.0, atol=1e-6) and np.isclose(F_shifted[0].imag, f_s_dw, rtol=1e-6)
    print(f"  Shifted (0.5,0,0) at h=0.5: F={F_shifted[0]:.6f}, expected=0+{f_s_dw:.6f}i, pass={check_shifted}")
    
    return check_origin and check_shifted


# ---------------------------------------------------------------------------
# NEW in v4.2: Asymmetric hkl-corner/step fixture test
# ---------------------------------------------------------------------------

def test_asymmetric_grid() -> bool:
    """
    Test that build_hkl_grid_from_metadata correctly handles asymmetric
    corner and increment vectors.
    
    Corner: (-1.0, -2.0, -3.0)
    Increment: (0.1, 0.2, 0.3)
    Dimensions: (5, 4, 3)
    
    Expected:
    h: -1.0, -0.9, -0.8, -0.7, -0.6
    k: -2.0, -1.8, -1.6, -1.4
    l: -3.0, -2.7, -2.4
    
    Returns:
        True if the grid is constructed correctly
    """
    nx, ny, nz = 5, 4, 3
    corner = np.array([-1.0, -2.0, -3.0])
    increment = np.array([
        [0.1, 0.0, 0.0],
        [0.0, 0.2, 0.0],
        [0.0, 0.0, 0.3],
    ])
    
    grid = build_hkl_grid_from_metadata(nx, ny, nz, corner, increment)
    
    # Check h axis
    h_expected = np.array([-1.0, -0.9, -0.8, -0.7, -0.6])
    h_actual = grid[0, 0, 0, 0]
    check_h = np.isclose(h_actual, h_expected[0])
    
    # Check k axis
    k_expected = np.array([-2.0, -1.8, -1.6, -1.4])
    k_actual = grid[0, 1, 0, 1]
    check_k = np.isclose(k_actual, k_expected[1])
    
    # Check l axis
    l_expected = np.array([-3.0, -2.7, -2.4])
    l_actual = grid[0, 0, 1, 2]
    check_l = np.isclose(l_actual, l_expected[1])
    
    print(f"  Asymmetric grid: h[0]={h_actual:.4f} (expected {h_expected[0]:.4f}), "
          f"k[1]={k_actual:.4f} (expected {k_expected[1]:.4f}), "
          f"l[1]={l_actual:.4f} (expected {l_expected[1]:.4f})")
    print(f"  Pass: h={check_h}, k={check_k}, l={check_l}")
    
    return check_h and check_k and check_l


# ---------------------------------------------------------------------------
# Main benchmark
# ---------------------------------------------------------------------------

def run_full_benchmark(
    stru_path: str,
    total_h5: str,
    diffuse_h5: str,
    output_json: str = None
) -> dict:
    """Run the full benchmark (total + diffuse) using IT92 form factors."""
    print(f"\n{'='*60}")
    print(f"INDEPENDENT STRUCTURE-FACTOR BENCHMARK (v4.2 — FULL METADATA GRID)")
    print(f"{'='*60}")
    
    # Read structure
    species, r_frac, biso = read_stru(stru_path)
    N = len(species)
    n_Ga = np.sum(species == 'GA')
    n_As = np.sum(species == 'AS')
    print(f"Atoms: {N} ({n_Ga} GA, {n_As} AS)")
    print(f"Coordinates: base-cell fractional units")
    print(f"  r_frac range: [{r_frac.min():.4f}, {r_frac.max():.4f}]")
    print(f"  Biso range: [{biso.min():.4f}, {biso.max():.4f}] A^2")
    
    # Compute site-resolved occupancies
    print("\nComputing site-resolved occupancies...")
    occupancies = compute_site_occupancies(species, r_frac)
    print(f"  Basis positions: {len(occupancies)}")
    for bp, (p_Ga, p_As, count) in sorted(occupancies.items()):
        print(f"    {bp}: GA={p_Ga:.4f} ({int(p_Ga*512)}/512), AS={p_As:.4f} ({int(p_As*512)}/512)")
    
    # Read DISCUS metadata (v4.2: use full 3-vector corner and 3 increment columns)
    with h5py.File(total_h5, "r") as h:
        data = h["entry"]["data"]
        a = float(data["unit_cell_lengths"][0])
        nx, ny, nz = data["data_dimension"][()]
        corner = data["data_corner"][:]  # (3,) array
        increment_vector = data["data_increment_vector"][:]  # (3, 3) array
        discus_total = data["data_values"][:]
    
    with h5py.File(diffuse_h5, "r") as h:
        discus_diffuse = h["entry"]["data"]["data_values"][:]
    
    print(f"\nUnit cell: a = {a:.6f} A")
    print(f"Grid: {nx}x{ny}x{nz}")
    print(f"  Corner: {corner}")
    print(f"  Increment vector:\n{increment_vector}")
    
    # Build hkl grid (v4.2: use full metadata)
    hkl_grid = build_hkl_grid_from_metadata(nx, ny, nz, corner, increment_vector)
    hkl_flat = hkl_grid.reshape(-1, 3)
    
    # Form factor functions
    f_Ga_fn = f_xray_Ga
    f_As_fn = f_xray_As
    
    f_Ga_0 = f_Ga_fn(np.array([0.0]))[0]
    f_As_0 = f_As_fn(np.array([0.0]))[0]
    print(f"Form factors (IT92): f_Ga(0)={f_Ga_0:.4f}, f_As(0)={f_As_0:.4f}")
    
    # Calculate F(hkl)
    print(f"\nCalculating F(hkl) for {len(hkl_flat)} grid points...")
    F_all = calculate_structure_factor(
        hkl_flat, r_frac, f_Ga_fn, f_As_fn, species, biso, a, chunk_size=32
    )
    
    # Total intensity
    I_total = np.abs(F_all)**2
    I_total = I_total.reshape(nx, ny, nz)
    print(f"  Total: max={I_total.max():.4e}, min={I_total.min():.4e}")
    
    # Site-resolved average structure factor (CORRECT interference)
    print("Calculating site-resolved average structure factor <F>(hkl)...")
    F_avg = calculate_average_structure_factor_site_resolved(
        hkl_flat, occupancies, f_Ga_fn, f_As_fn, a, biso=1.0, n_min=-4, n_max=3
    )
    
    # Amplitude-based diffuse: |F(hkl) - <F>(hkl)|^2
    I_diff_amplitude = np.abs(F_all - F_avg)**2
    I_diff_amplitude = I_diff_amplitude.reshape(nx, ny, nz)
    print(f"  Diffuse (amplitude): max={I_diff_amplitude.max():.4e}, min={I_diff_amplitude.min():.4e}")
    
    # NEW in v4.2: Direct-site-average oracle
    print("Calculating direct-site-average oracle <F>(hkl)...")
    F_avg_direct = calculate_average_structure_factor_direct_site(
        hkl_flat, r_frac, species, biso, f_Ga_fn, f_As_fn, a, chunk_size=32
    )
    
    # Compare factored vs direct-site-average
    max_diff_oracle = np.max(np.abs(F_avg - F_avg_direct))
    print(f"  Max |F_avg_factored - F_avg_direct| = {max_diff_oracle:.4e}")
    
    # Compare
    results = {}
    for name, ind, disc in [
        ("total", I_total, discus_total),
        ("diffuse_amplitude", I_diff_amplitude, discus_diffuse),
    ]:
        metrics = compute_metrics(ind, disc)
        hkl_at_max = hkl_grid[tuple(metrics["largest_residual_index"])]
        
        discus_max_idx = np.unravel_index(np.argmax(disc), disc.shape)
        discus_peak_hkl = hkl_grid[discus_max_idx]
        discus_peak_val = disc[discus_max_idx]
        ind_peak_val = ind[discus_max_idx]
        
        metrics["largest_residual_hkl"] = [float(x) for x in hkl_at_max]
        metrics["discus_peak_hkl"] = [float(x) for x in discus_peak_hkl]
        metrics["discus_peak_value"] = float(discus_peak_val)
        metrics["independent_at_discus_peak"] = float(ind_peak_val)
        
        results[name] = metrics
        
        print(f"\n  {name}: rel_L2={metrics['rel_l2']:.6e}, pearson={metrics['pearson']:.8f}, "
              f"max_diff={metrics['max_abs_diff']:.4e} at hkl={hkl_at_max}")
        print(f"    DISCUS peak: {discus_peak_val:.4e} at hkl={discus_peak_hkl}, "
              f"independent at same point: {ind_peak_val:.4e}")
    
    # (0,0,0) comparison
    # Find the index of (0,0,0) in the grid
    origin_idx = None
    for i in range(nx):
        for j in range(ny):
            for k in range(nz):
                if np.allclose(hkl_grid[i, j, k], [0, 0, 0], atol=1e-6):
                    origin_idx = (i, j, k)
                    break
            if origin_idx:
                break
        if origin_idx:
            break
    
    if origin_idx:
        results["origin_comparison"] = {
            "discus": float(discus_total[origin_idx]),
            "independent": float(I_total[origin_idx]),
            "ratio": float(I_total[origin_idx] / discus_total[origin_idx]) if discus_total[origin_idx] != 0 else float('nan'),
        }
        print(f"\n  (0,0,0): DISCUS={discus_total[origin_idx]:.4e}, "
              f"independent={I_total[origin_idx]:.4e}, "
              f"ratio={results['origin_comparison']['ratio']:.6f}")
    
    # Verify: |F - F_avg| at integer hkl should be ~0
    int_mask = np.zeros((nx, ny, nz), dtype=bool)
    for i in range(nx):
        for j in range(ny):
            for k in range(nz):
                if np.allclose(hkl_grid[i, j, k], np.round(hkl_grid[i, j, k]), atol=1e-6):
                    int_mask[i, j, k] = True
    
    F_avg_3d = F_avg.reshape(nx, ny, nz)
    max_diff_int = np.max(np.abs(F_all.reshape(nx, ny, nz) - F_avg_3d)[int_mask])
    max_diff_int_sq = np.max((np.abs(F_all.reshape(nx, ny, nz) - F_avg_3d)**2)[int_mask])
    results["integer_hkl_verification"] = {
        "max_abs_F_minus_Favg_at_integer": float(max_diff_int),
        "max_abs_F_minus_Favg_squared_at_integer": float(max_diff_int_sq),
        "max_discus_diffuse_at_integer": float(discus_diffuse[int_mask].max()),
    }
    print(f"\n  Integer-hkl verification:")
    print(f"    max |F - F_avg| at integer hkl: {max_diff_int:.4e}")
    print(f"    max |F - F_avg|^2 at integer hkl: {max_diff_int_sq:.4e}")
    print(f"    max DISCUS diffuse at integer hkl: {discus_diffuse[int_mask].max():.4e}")
    
    # Off-grid verification (v4)
    print("\n  Off-grid verification (v4):")
    off_grid_points = [
        (0.05, 0.0, 0.0),
        (0.10, 0.0, 0.0),
        (0.10, 0.15, 0.07),
    ]
    results["off_grid_verification"] = {}
    for hkl_test in off_grid_points:
        hkl_test_arr = np.array([hkl_test])
        F_test = calculate_structure_factor(
            hkl_test_arr, r_frac, f_Ga_fn, f_As_fn, species, biso, a
        )
        F_avg_test = calculate_average_structure_factor_site_resolved(
            hkl_test_arr, occupancies, f_Ga_fn, f_As_fn, a, biso=1.0, n_min=-4, n_max=3
        )
        I_diff_test = np.abs(F_test - F_avg_test)**2
        # Interference factor at this point
        h_int = interference_factor(np.array([hkl_test[0]]))
        k_int = interference_factor(np.array([hkl_test[1]]))
        l_int = interference_factor(np.array([hkl_test[2]]))
        results["off_grid_verification"][str(hkl_test)] = {
            "I_diff": float(I_diff_test[0]),
            "interference_h_real": float(h_int[0].real),
            "interference_h_imag": float(h_int[0].imag),
            "interference_k_real": float(k_int[0].real),
            "interference_k_imag": float(k_int[0].imag),
            "interference_l_real": float(l_int[0].real),
            "interference_l_imag": float(l_int[0].imag),
        }
        print(f"    hkl={hkl_test}: I_diff={I_diff_test[0]:.4e}, "
              f"|interference|={abs(h_int[0]*k_int[0]*l_int[0]):.4e}")
    
    if output_json:
        with open(output_json, "w") as f:
            json.dump(results, f, indent=2)
        print(f"\nResults written to {output_json}")
    
    return results


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Independent structure-factor benchmark (v4.2)")
    parser.add_argument("--stru", required=True, help="Path to .stru file")
    parser.add_argument("--total", required=True, help="Path to DISCUS total HDF5")
    parser.add_argument("--diffuse", required=True, help="Path to DISCUS diffuse HDF5")
    parser.add_argument("--output", default=None, help="Output JSON path")
    parser.add_argument("--test", action="store_true", help="Run unit tests")
    
    args = parser.parse_args()
    
    if args.test:
        print("\nRunning unit tests...")
        print("\n1. Synthetic supercell test:")
        test_synthetic_supercell()
        print("\n2. Origin-shift phase test:")
        test_origin_shift_phase()
        print("\n3. Asymmetric grid test:")
        test_asymmetric_grid()
        print("\nAll tests complete.")
    else:
        results = run_full_benchmark(
            args.stru, args.total, args.diffuse,
            output_json=args.output
        )
