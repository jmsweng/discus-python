#!/usr/bin/env python3
"""
Regression tests for the independent structure-factor calculation.

Uses small analytical examples with known exact solutions.
"""

import numpy as np
import sys
import os

# Add the parent directory to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from independent_structure_factor import (
    f_xray_Ga,
    f_xray_As,
    calculate_structure_factor_q,
    build_hkl_grid,
)


def test_f_xray_at_zero():
    """Test that f(0) = Z for both elements."""
    Q0 = np.array([0.0])
    
    f_Ga0 = f_xray_Ga(Q0)[0]
    f_As0 = f_xray_As(Q0)[0]
    
    assert abs(f_Ga0 - 31.0) < 1e-6, f"f_Ga(0) = {f_Ga0}, expected 31.0"
    assert abs(f_As0 - 33.0) < 1e-6, f"f_As(0) = {f_As0}, expected 33.0"
    
    print(f"  f_Ga(0) = {f_Ga0:.6f} (expected 31.0) ✓")
    print(f"  f_As(0) = {f_As0:.6f} (expected 33.0) ✓")


def test_f_xray_monotonic():
    """Test that f(Q) decreases monotonically with Q."""
    Q = np.array([0.0, 1.0, 2.0, 3.0, 4.0])
    
    f_Ga = f_xray_Ga(Q)
    f_As = f_xray_As(Q)
    
    # Check monotonic decrease
    for i in range(len(Q) - 1):
        assert f_Ga[i] > f_Ga[i+1], f"f_Ga not monotonic at Q={Q[i]}"
        assert f_As[i] > f_As[i+1], f"f_As not monotonic at Q={Q[i]}"
    
    print(f"  f_Ga: {f_Ga} (monotonically decreasing) ✓")
    print(f"  f_As: {f_As} (monotonically decreasing) ✓")


def test_single_atom_structure_factor():
    """
    Test the structure factor for a single atom at the origin.
    
    For a single atom at (0,0,0) with scattering factor f:
    F(hkl) = f * exp(2*pi*i * h*0) = f
    
    So |F(hkl)|^2 = f^2 for all hkl.
    """
    # Single atom at origin
    r_frac = np.array([[0.0, 0.0, 0.0]])
    species = np.array(['GA'])
    
    # Use a constant scattering factor (f=1) for simplicity
    def f_const(Q):
        return np.ones_like(Q)
    
    hkl = np.array([[0.0, 0.0, 0.0],
                    [1.0, 0.0, 0.0],
                    [0.5, 0.5, 0.5],
                    [2.0, 1.0, -1.0]])
    
    F = calculate_structure_factor_q(
        hkl, r_frac, f_const, f_const, species, a=1.0, chunk_size=4
    )
    
    # F should be 1.0 for all hkl (single atom at origin)
    for i, f_val in enumerate(F):
        assert abs(f_val - 1.0) < 1e-10, f"F({hkl[i]}) = {f_val}, expected 1.0"
    
    print(f"  Single atom at origin: F = {F} (all 1.0) ✓")


def test_two_atom_structure_factor():
    """
    Test the structure factor for two atoms.
    
    Atom 1 at (0, 0, 0) with f=1
    Atom 2 at (0.5, 0, 0) with f=1
    
    F(hkl) = 1 * exp(0) + 1 * exp(2*pi*i * h*0.5)
           = 1 + exp(pi*i * h)
    
    At h=0: F = 1 + 1 = 2
    At h=1: F = 1 + exp(pi*i) = 1 + (-1) = 0
    At h=2: F = 1 + exp(2*pi*i) = 1 + 1 = 2
    """
    r_frac = np.array([[0.0, 0.0, 0.0],
                       [0.5, 0.0, 0.0]])
    species = np.array(['GA', 'GA'])
    
    def f_const(Q):
        return np.ones_like(Q)
    
    hkl = np.array([[0.0, 0.0, 0.0],
                    [1.0, 0.0, 0.0],
                    [2.0, 0.0, 0.0],
                    [0.5, 0.0, 0.0]])
    
    F = calculate_structure_factor_q(
        hkl, r_frac, f_const, f_const, species, a=1.0, chunk_size=4
    )
    
    # Expected values:
    # h=0: F = 2
    # h=1: F = 0
    # h=2: F = 2
    # h=0.5: F = 1 + exp(pi*i*0.5) = 1 + exp(i*pi/2) = 1 + i
    expected = np.array([2.0, 0.0, 2.0, 1.0 + 1.0j])
    
    for i in range(len(hkl)):
        diff = abs(F[i] - expected[i])
        assert diff < 1e-10, f"F({hkl[i]}) = {F[i]}, expected {expected[i]}, diff={diff}"
    
    print(f"  Two atoms: F = {F}")
    print(f"  Expected:  {expected} ✓")


def test_intensity_at_origin():
    """
    Test that the intensity at (0,0,0) equals (sum of f_j)^2.
    
    For N atoms with scattering factors f_j:
    F(0,0,0) = sum_j f_j
    I(0,0,0) = |F(0,0,0)|^2 = (sum_j f_j)^2
    """
    # 4 GA atoms (f=31) and 4 AS atoms (f=33)
    r_frac = np.zeros((8, 3))
    species = np.array(['GA'] * 4 + ['AS'] * 4)
    
    hkl = np.array([[0.0, 0.0, 0.0]])
    
    F = calculate_structure_factor_q(
        hkl, r_frac, f_xray_Ga, f_xray_As, species, a=1.0, chunk_size=1
    )
    
    F_expected = 4 * 31.0 + 4 * 33.0  # = 124 + 132 = 256
    I_expected = F_expected**2  # = 65536
    
    assert abs(F[0].real - F_expected) < 1e-6, f"F(0,0,0) = {F[0].real}, expected {F_expected}"
    assert abs(abs(F[0])**2 - I_expected) < 1e-4, f"I(0,0,0) = {abs(F[0])**2}, expected {I_expected}"
    
    print(f"  F(0,0,0) = {F[0].real:.4f} (expected {F_expected}) ✓")
    print(f"  I(0,0,0) = {abs(F[0])**2:.4f} (expected {I_expected}) ✓")


def test_bragg_mask():
    """
    Test the Bragg-mask subtraction.
    
    At integer hkl: diffuse = 0
    At non-integer hkl: diffuse = total
    """
    # Create a simple intensity grid
    nx = ny = nz = 9
    I_total = np.ones((nx, ny, nz))
    
    # Apply Bragg mask
    I_diff = I_total.copy()
    int_indices = np.arange(0, 9, 8)  # 0, 8
    for i in int_indices:
        for j in int_indices:
            for k in int_indices:
                I_diff[i, j, k] = 0.0
    
    # Check: integer hkl points should be 0
    for i in int_indices:
        for j in int_indices:
            for k in int_indices:
                assert I_diff[i, j, k] == 0.0, f"Diffuse at ({i},{j},{k}) should be 0"
    
    # Check: non-integer hkl points should be 1
    for i in range(nx):
        for j in range(ny):
            for k in range(nz):
                if i not in int_indices and j not in int_indices and k not in int_indices:
                    assert I_diff[i, j, k] == 1.0, f"Diffuse at ({i},{j},{k}) should be 1"
    
    n_zero = np.sum(I_diff == 0)
    n_nonzero = np.sum(I_diff == 1)
    print(f"  Bragg mask: {n_zero} zero points, {n_nonzero} nonzero points ✓")


def test_hkl_grid():
    """Test the hkl grid construction."""
    nx = ny = nz = 5
    hmin = -2.0
    step = 1.0
    
    hkl_grid = build_hkl_grid(nx, ny, nz, hmin, step)
    
    # Check shape
    assert hkl_grid.shape == (5, 5, 5, 3), f"Shape = {hkl_grid.shape}"
    
    # Check values
    expected_h = np.arange(5) * 1.0 - 2.0  # [-2, -1, 0, 1, 2]
    for i in range(5):
        assert abs(hkl_grid[i, 0, 0, 0] - expected_h[i]) < 1e-10
        assert abs(hkl_grid[0, i, 0, 1] - expected_h[i]) < 1e-10
        assert abs(hkl_grid[0, 0, i, 2] - expected_h[i]) < 1e-10
    
    print(f"  hkl grid: shape={hkl_grid.shape}, h range=[{hkl_grid[0,0,0,0]}, {hkl_grid[4,0,0,0]}] ✓")


if __name__ == "__main__":
    print("=== Regression Tests ===\n")
    
    print("1. Test f_xray at Q=0:")
    test_f_xray_at_zero()
    
    print("\n2. Test f_xray monotonicity:")
    test_f_xray_monotonic()
    
    print("\n3. Test single atom structure factor:")
    test_single_atom_structure_factor()
    
    print("\n4. Test two atom structure factor:")
    test_two_atom_structure_factor()
    
    print("\n5. Test intensity at origin:")
    test_intensity_at_origin()
    
    print("\n6. Test Bragg mask:")
    test_bragg_mask()
    
    print("\n7. Test hkl grid:")
    test_hkl_grid()
    
    print("\n=== All tests passed! ===")
