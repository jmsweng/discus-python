#!/usr/bin/env python3
"""
Independent kinematic structure-factor calculation for DISCUS 6.23.01 validation.

CORRECTED VERSION (v3) — addresses v2 review findings:

1. Coordinates: The .stru file stores positions in BASE-CELL FRACTIONAL units.
   Use them directly in exp(2*pi*i * h.r). Do NOT divide by the lattice constant.

2. Form factors: Uses published Gemmi IT92 (International Tables 1992)
   X-ray scattering factors for Ga and As.

3. Debye-Waller: Includes the isotropic Debye-Waller factor exp(-Biso*s^2)
   where s = sin(theta)/lambda = |hkl| / (2*a) for cubic crystals.
   All atoms in C1_frozen.stru have Biso = 1.0 A^2.

4. Average structure: Uses a SITE-RESOLVED occupancy model.
   The 4096-atom supercell has 8 distinct crystallographic basis positions,
   each repeated 512 times across an 8x8x8 supercell. For each basis site b,
   the empirical occupancy p_Ga,b = number_Ga_on_b / 512.
   
   F_avg(hkl) = exp(-Biso*s^2) * sum_b [f_avg,b(s) * exp(2pi*i * hkl.dot(b))]
              * product_j sum_n exp(2pi*i * j*n)
   
   where f_avg,b(s) = p_Ga,b * f_Ga(s) + p_As,b * f_As(s)
   and the product term is the 8-cell translation interference factor.

   This is a genuine amplitude-level average-structure model for the saved,
   periodically repeated 8-site basis. It is NOT a universal ensemble average.

Conventions:
- hkl are in units of the reciprocal lattice (basecell_fractional)
- s = |hkl| / (2*a)  [sin(theta)/lambda for cubic crystals]
- f_j(s) is the X-ray atomic scattering factor (electrons)
- Total intensity I(hkl) = |F(hkl)|^2
- F(hkl) = sum_j f_j(s) * exp(-Biso_j * s^2) * exp(2*pi*i * h.r_j)
"""

import numpy as np
import h5py
import os
import json
import sys
from typing import Tuple, Dict

try:
    import gemmi
    HAS_GEMMI = True
except ImportError:
    HAS_GEMMI = False

# ---------------------------------------------------------------------------
# X-ray atomic scattering factors (IT92 / International Tables 1992)
# ---------------------------------------------------------------------------

IT92_GA = {
    "a": [15.2354, 6.7006, 4.3591, 2.9623],
    "b": [3.0669, 0.2412, 10.7805, 61.4135],
    "c": 1.7189,
}

IT92_AS = {
    "a": [16.6723, 6.0701, 3.4313, 4.2779],
    "b": [2.6345, 0.2647, 12.9479, 47.7972],
    "c": 2.531,
}


def f_xray_Ga(s: np.ndarray) -> np.ndarray:
    """
    X-ray scattering factor for Gallium (Ga, Z=31).
    Uses the IT92 parameterization. f(0) = 30.9763.
    """
    if HAS_GEMMI:
        it92 = gemmi.Element('Ga').it92
        a = np.array([float(x) for x in it92.a])
        b = np.array([float(x) for x in it92.b])
        c = float(it92.c)
    else:
        a = np.array(IT92_GA["a"])
        b = np.array(IT92_GA["b"])
        c = IT92_GA["c"]
    
    s2 = s**2
    f = np.zeros_like(s2)
    for ai, bi in zip(a, b):
        f += ai * np.exp(-bi * s2)
    f += c
    return f


def f_xray_As(s: np.ndarray) -> np.ndarray:
    """
    X-ray scattering factor for Arsenic (As, Z=33).
    Uses the IT92 parameterization. f(0) = 32.9826.
    """
    if HAS_GEMMI:
        it92 = gemmi.Element('As').it92
        a = np.array([float(x) for x in it92.a])
        b = np.array([float(x) for x in it92.b])
        c = float(it92.c)
    else:
        a = np.array(IT92_AS["a"])
        b = np.array(IT92_AS["b"])
        c = IT92_AS["c"]
    
    s2 = s**2
    f = np.zeros_like(s2)
    for ai, bi in zip(a, b):
        f += ai * np.exp(-bi * s2)
    f += c
    return f


# ---------------------------------------------------------------------------
# Structure file reader
# ---------------------------------------------------------------------------

def read_stru(path: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Read a DISCUS .stru file.
    
    IMPORTANT: The positions in the .stru file are in BASE-CELL FRACTIONAL
    units, NOT Cartesian Angstroms. Use them directly as fractional coordinates.
    
    Returns:
        species: array of species labels (str)
        r_frac: (N, 3) array of fractional coordinates (base-cell units)
        biso: (N,) array of Biso values (A^2)
    """
    species_list = []
    r_frac_list = []
    biso_list = []
    
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith(('title', 'spcgr', 'cell', 'format', 'atoms')):
                continue
            parts = line.split()
            if len(parts) < 4:
                continue
            species = parts[0].upper()
            if species not in ('GA', 'AS'):
                continue
            vals = []
            for tok in parts[1:5]:
                try:
                    vals.append(float(tok.rstrip(',')))
                except ValueError:
                    break
            if len(vals) < 4:
                continue
            r_frac_list.append(vals[:3])
            biso_list.append(vals[3])
            species_list.append(species)
    
    return (np.array(species_list),
            np.array(r_frac_list, dtype=float),
            np.array(biso_list, dtype=float))


# ---------------------------------------------------------------------------
# Site-resolved average structure factor
# ---------------------------------------------------------------------------

def compute_site_occupancies(
    species: np.ndarray,
    r_frac: np.ndarray
) -> Dict[np.ndarray, Tuple[float, float, np.ndarray]]:
    """
    Compute site-resolved occupancies for the 8 basis positions.
    
    The 4096-atom supercell has 8 distinct crystallographic basis positions,
    each repeated 512 times across an 8x8x8 supercell.
    
    Returns:
        dict mapping basis position (3,) array to (p_Ga, p_As, count)
    """
    N = len(species)
    if N != 4096:
        raise ValueError(f"Expected 4096 atoms, got {N}")
    
    # Group sites by their fractional part (basis position)
    # The basis positions are at quarter-cell increments
    basis_positions = np.round(r_frac % 1.0, decimals=4)
    
    # Find unique basis positions
    unique_basis = []
    occupancies = {}
    
    for i in range(N):
        bp = tuple(basis_positions[i])
        if bp not in occupancies:
            occupancies[bp] = {"GA": 0, "AS": 0}
            unique_basis.append(bp)
        occupancies[bp][species[i]] += 1
    
    # Verify: 8 unique basis positions, each with 512 sites
    if len(unique_basis) != 8:
        raise ValueError(f"Expected 8 basis positions, got {len(unique_basis)}")
    
    result = {}
    for bp in unique_basis:
        counts = occupancies[bp]
        total = counts["GA"] + counts["AS"]
        if total != 512:
            raise ValueError(f"Basis {bp}: expected 512 sites, got {total}")
        p_Ga = counts["GA"] / 512.0
        p_As = counts["AS"] / 512.0
        result[bp] = (p_Ga, p_As, total)
    
    return result


def calculate_average_structure_factor_site_resolved(
    hkl: np.ndarray,
    basis_occupancies: Dict[np.ndarray, Tuple[float, float, int]],
    f_Ga_fn,
    f_As_fn,
    a: float,
    biso: float = 1.0,
    n_cells: int = 8
) -> np.ndarray:
    """
    Calculate the site-resolved average structure factor <F>(hkl).
    
    For a periodically repeated 8-site basis with empirical occupancies:
    
    F_avg(hkl) = exp(-Biso*s^2)
        * sum_b [f_avg,b(s) * exp(2pi*i * hkl.dot(b))]
        * product_{j=h,k,l} sum_{n=0}^{N-1} exp(2pi*i * j*n)
    
    where:
    - b iterates over the 8 basis positions
    - f_avg,b(s) = p_Ga,b * f_Ga(s) + p_As,b * f_As(s)
    - s = |hkl| / (2*a)
    - N = n_cells (8 for the 8x8x8 supercell)
    - The product term is the interference factor for the N-cell supercell
    
    The interference factor sum_{n=0}^{N-1} exp(2pi*i*j*n) equals:
    - N if j is a multiple of 1/N (i.e., j*N is an integer)
    - 0 otherwise
    
    For the 65-point grid with step 0.125 = 1/8:
    - j is a multiple of 1/8 for all grid points
    - j is a multiple of 1 (integer) only at the 9 integer points per axis
    - So the interference factor is 512 at integer hkl, 0 elsewhere
    
    This means F_avg is nonzero ONLY at integer hkl, where it equals:
    F_avg(hkl) = 512 * exp(-Biso*s^2) * sum_b [f_avg,b(s) * exp(2pi*i * hkl.dot(b))]
    
    Args:
        hkl: (M, 3) array of hkl values
        basis_occupancies: dict from compute_site_occupancies()
        f_Ga_fn: callable for Ga scattering factor
        f_As_fn: callable for As scattering factor
        a: lattice constant (A)
        biso: Debye-Waller parameter (A^2)
        n_cells: number of unit cells per supercell edge (8)
    
    Returns:
        F_avg: (M,) complex array
    """
    M = hkl.shape[0]
    F_avg = np.zeros(M, dtype=complex)
    
    basis_list = list(basis_occupancies.keys())
    
    for start in range(0, M, 32):
        end = min(start + 32, M)
        h_chunk = hkl[start:end]  # (C, 3)
        
        s_chunk = np.linalg.norm(h_chunk, axis=1) / (2.0 * a)  # (C,)
        s2_chunk = s_chunk**2
        dw = np.exp(-biso * s2_chunk)  # (C,)
        
        f_Ga_chunk = f_Ga_fn(s_chunk)  # (C,)
        f_As_chunk = f_As_fn(s_chunk)  # (C,)
        
        # Sum over basis sites
        F_basis = np.zeros(end - start, dtype=complex)
        for bp in basis_list:
            p_Ga, p_As, _ = basis_occupancies[bp]
            f_avg = p_Ga * f_Ga_chunk + p_As * f_As_chunk  # (C,)
            
            # Phase: exp(2pi*i * hkl.dot(bp))
            dot = h_chunk @ np.array(bp)  # (C,)
            phase = 2 * np.pi * dot
            F_basis += f_avg * np.exp(1j * phase)
        
        # Interference factor: product_j sum_{n=0}^{N-1} exp(2pi*i*j*n)
        # For j = m/N (m integer), this is N if m is a multiple of N, else 0
        # On the 65-point grid with step 1/8: j = m/8
        # The factor is 8^3 = 512 if h,k,l are all integers, else 0
        # (Since the grid step is 1/8, "integer" means j*8 is an integer,
        #  which is true for ALL grid points. But the interference factor
        #  is N only when j is an integer multiple of 1, i.e., j*8 is a
        #  multiple of 8, i.e., j is an integer.)
        
        # Check if hkl are all integers (within floating point tolerance)
        # j is integer if j * 8 is a multiple of 8, i.e., j is integer
        is_integer = np.all(np.abs(h_chunk - np.round(h_chunk)) < 1e-6, axis=1)
        
        # Interference factor: 512 at integer hkl, 0 elsewhere
        interference = np.where(is_integer, n_cells**3, 0.0)  # (C,)
        
        F_avg[start:end] = dw * F_basis * interference
    
    return F_avg


# ---------------------------------------------------------------------------
# Structure factor calculation (direct sum)
# ---------------------------------------------------------------------------

def calculate_structure_factor(
    hkl: np.ndarray,
    r_frac: np.ndarray,
    f_Ga_fn,
    f_As_fn,
    species: np.ndarray,
    biso: np.ndarray,
    a: float,
    chunk_size: int = 32
) -> np.ndarray:
    """
    Calculate F(hkl) = sum_j f_j(s) * exp(-Biso_j * s^2) * exp(2*pi*i * h.r_j)
    
    where s = |hkl| / (2*a) for cubic crystals.
    """
    M = hkl.shape[0]
    F = np.zeros(M, dtype=complex)
    
    ga_mask = (species == 'GA')
    r_Ga = r_frac[ga_mask]
    biso_Ga = biso[ga_mask]
    r_As = r_frac[~ga_mask]
    biso_As = biso[~ga_mask]
    
    for start in range(0, M, chunk_size):
        end = min(start + chunk_size, M)
        h_chunk = hkl[start:end]
        
        hkl_mag = np.linalg.norm(h_chunk, axis=1)
        s_chunk = hkl_mag / (2.0 * a)
        
        f_Ga_chunk = f_Ga_fn(s_chunk)
        f_As_chunk = f_As_fn(s_chunk)
        
        s2_chunk = s_chunk**2
        dw_Ga = np.exp(-biso_Ga * s2_chunk[:, np.newaxis])
        dw_As = np.exp(-biso_As * s2_chunk[:, np.newaxis])
        
        dot_Ga = h_chunk @ r_Ga.T
        F_Ga_chunk = f_Ga_chunk * np.sum(dw_Ga * np.exp(1j * 2 * np.pi * dot_Ga), axis=1)
        
        dot_As = h_chunk @ r_As.T
        F_As_chunk = f_As_chunk * np.sum(dw_As * np.exp(1j * 2 * np.pi * dot_As), axis=1)
        
        F[start:end] = F_Ga_chunk + F_As_chunk
    
    return F


def build_hkl_grid(
    nx: int, ny: int, nz: int,
    hmin: float, step: float
) -> np.ndarray:
    """Build a 3D hkl grid."""
    h_vals = np.arange(nx) * step + hmin
    k_vals = np.arange(ny) * step + hmin
    l_vals = np.arange(nz) * step + hmin
    
    H, K, L = np.meshgrid(h_vals, k_vals, l_vals, indexing='ij')
    return np.stack([H, K, L], axis=-1)


# ---------------------------------------------------------------------------
# Comparison metrics
# ---------------------------------------------------------------------------

def compute_metrics(independent: np.ndarray, discus: np.ndarray) -> dict:
    """Compute comparison metrics."""
    diff = np.abs(independent - discus)
    l2_diff = np.sqrt(np.sum(diff**2))
    l2_discus = np.sqrt(np.sum(discus**2))
    rel_l2 = l2_diff / l2_discus if l2_discus != 0 else float('inf')
    
    if independent.std() > 0 and discus.std() > 0:
        pearson = np.corrcoef(independent.flatten(), discus.flatten())[0, 1]
    else:
        pearson = float('nan')
    
    nonzero = np.abs(discus) > 1e-10
    if nonzero.any():
        scale_ratio = np.mean(independent[nonzero] / discus[nonzero])
    else:
        scale_ratio = float('nan')
    
    max_idx = np.unravel_index(np.argmax(diff), diff.shape)
    
    return {
        "max_abs_diff": float(diff.max()),
        "mean_abs_diff": float(diff.mean()),
        "rel_l2": float(rel_l2),
        "pearson": float(pearson),
        "scale_ratio": float(scale_ratio),
        "independent_max": float(independent.max()),
        "discus_max": float(discus.max()),
        "independent_mean": float(independent.mean()),
        "discus_mean": float(discus.mean()),
        "largest_residual_index": [int(x) for x in max_idx],
    }


# ---------------------------------------------------------------------------
# Main benchmark
# ---------------------------------------------------------------------------

def run_full_benchmark(
    stru_path: str,
    total_h5: str,
    diffuse_h5: str,
    output_json: str = None
) -> dict:
    """Run the full benchmark (total + diffuse) using IT92 form factors."""
    print(f"\n{'='*60}")
    print(f"INDEPENDENT STRUCTURE-FACTOR BENCHMARK (v3 — SITE-RESOLVED AVERAGE)")
    print(f"{'='*60}")
    
    # Read structure
    species, r_frac, biso = read_stru(stru_path)
    N = len(species)
    n_Ga = np.sum(species == 'GA')
    n_As = np.sum(species == 'AS')
    print(f"Atoms: {N} ({n_Ga} GA, {n_As} AS)")
    print(f"Coordinates: base-cell fractional units")
    print(f"  r_frac range: [{r_frac.min():.4f}, {r_frac.max():.4f}]")
    print(f"  Biso range: [{biso.min():.4f}, {biso.max():.4f}] A^2")
    
    # Compute site-resolved occupancies
    print("\nComputing site-resolved occupancies...")
    occupancies = compute_site_occupancies(species, r_frac)
    print(f"  Basis positions: {len(occupancies)}")
    for bp, (p_Ga, p_As, count) in sorted(occupancies.items()):
        print(f"    {np.array(bp)}: GA={p_Ga:.4f} ({int(p_Ga*512)}/512), AS={p_As:.4f} ({int(p_As*512)}/512)")
    
    # Read DISCUS metadata
    with h5py.File(total_h5, "r") as h:
        data = h["entry"]["data"]
        a = float(data["unit_cell_lengths"][0])
        nx, ny, nz = data["data_dimension"][()]
        hmin = float(data["data_corner"][0])
        step = float(data["data_increment_vector"][0, 0])
        discus_total = data["data_values"][:]
    
    with h5py.File(diffuse_h5, "r") as h:
        discus_diffuse = h["entry"]["data"]["data_values"][:]
    
    print(f"\nUnit cell: a = {a:.6f} A")
    print(f"Grid: {nx}x{ny}x{nz}, hmin={hmin}, step={step}")
    
    # Build hkl grid
    hkl_grid = build_hkl_grid(nx, ny, nz, hmin, step)
    hkl_flat = hkl_grid.reshape(-1, 3)
    
    # Form factor functions
    f_Ga_fn = f_xray_Ga
    f_As_fn = f_xray_As
    
    f_Ga_0 = f_Ga_fn(np.array([0.0]))[0]
    f_As_0 = f_As_fn(np.array([0.0]))[0]
    print(f"Form factors (IT92): f_Ga(0)={f_Ga_0:.4f}, f_As(0)={f_As_0:.4f}")
    
    # Calculate F(hkl)
    print(f"\nCalculating F(hkl) for {len(hkl_flat)} grid points...")
    F_all = calculate_structure_factor(
        hkl_flat, r_frac, f_Ga_fn, f_As_fn, species, biso, a, chunk_size=32
    )
    
    # Total intensity
    I_total = np.abs(F_all)**2
    I_total = I_total.reshape(nx, ny, nz)
    print(f"  Total: max={I_total.max():.4e}, min={I_total.min():.4e}")
    
    # Site-resolved average structure factor
    print("Calculating site-resolved average structure factor <F>(hkl)...")
    F_avg = calculate_average_structure_factor_site_resolved(
        hkl_flat, occupancies, f_Ga_fn, f_As_fn, a, biso=1.0, n_cells=8
    )
    
    # Amplitude-based diffuse: |F(hkl) - <F>(hkl)|^2
    I_diff_amplitude = np.abs(F_all - F_avg)**2
    I_diff_amplitude = I_diff_amplitude.reshape(nx, ny, nz)
    print(f"  Diffuse (amplitude): max={I_diff_amplitude.max():.4e}, min={I_diff_amplitude.min():.4e}")
    
    # Empirical mask-based diffuse
    I_diff_mask = I_total.copy()
    int_indices = np.arange(0, 65, 8)
    for i in int_indices:
        for j in int_indices:
            for k in int_indices:
                I_diff_mask[i, j, k] = 0.0
    print(f"  Diffuse (mask): max={I_diff_mask.max():.4e}, min={I_diff_mask.min():.4e}")
    
    # Compare
    results = {}
    for name, ind, disc in [
        ("total", I_total, discus_total),
        ("diffuse_amplitude", I_diff_amplitude, discus_diffuse),
        ("diffuse_mask", I_diff_mask, discus_diffuse),
    ]:
        metrics = compute_metrics(ind, disc)
        hkl_at_max = hkl_grid[tuple(metrics["largest_residual_index"])]
        
        discus_max_idx = np.unravel_index(np.argmax(disc), disc.shape)
        discus_peak_hkl = hkl_grid[discus_max_idx]
        discus_peak_val = disc[discus_max_idx]
        ind_peak_val = ind[discus_max_idx]
        
        metrics["largest_residual_hkl"] = [float(x) for x in hkl_at_max]
        metrics["discus_peak_hkl"] = [float(x) for x in discus_peak_hkl]
        metrics["discus_peak_value"] = float(discus_peak_val)
        metrics["independent_at_discus_peak"] = float(ind_peak_val)
        
        results[name] = metrics
        
        print(f"\n  {name}: rel_L2={metrics['rel_l2']:.6e}, pearson={metrics['pearson']:.8f}, "
              f"max_diff={metrics['max_abs_diff']:.4e} at hkl={hkl_at_max}")
        print(f"    DISCUS peak: {discus_peak_val:.4e} at hkl={discus_peak_hkl}, "
              f"independent at same point: {ind_peak_val:.4e}")
    
    # (0,0,0) comparison
    origin_idx = (32, 32, 32)
    results["origin_comparison"] = {
        "discus": float(discus_total[origin_idx]),
        "independent": float(I_total[origin_idx]),
        "ratio": float(I_total[origin_idx] / discus_total[origin_idx]) if discus_total[origin_idx] != 0 else float('nan'),
    }
    print(f"\n  (0,0,0): DISCUS={discus_total[origin_idx]:.4e}, "
          f"independent={I_total[origin_idx]:.4e}, "
          f"ratio={results['origin_comparison']['ratio']:.6f}")
    
    # Example hkl point
    example_idx = (31, 32, 32)
    results["example_hkl_(-0.125,0,0)"] = {
        "discus": float(discus_total[example_idx]),
        "independent": float(I_total[example_idx]),
        "ratio": float(I_total[example_idx] / discus_total[example_idx]) if discus_total[example_idx] != 0 else float('nan'),
    }
    print(f"  (-0.125,0,0): DISCUS={discus_total[example_idx]:.4e}, "
          f"independent={I_total[example_idx]:.4e}, "
          f"ratio={results['example_hkl_(-0.125,0,0)']['ratio']:.6f}")
    
    # Verify: |F - F_avg| at integer hkl should be ~0
    int_mask = np.zeros((nx, ny, nz), dtype=bool)
    for i in np.arange(0, 65, 8):
        for j in np.arange(0, 65, 8):
            for k in np.arange(0, 65, 8):
                int_mask[i, j, k] = True
    
    F_avg_3d = F_avg.reshape(nx, ny, nz)
    max_diff_int = np.max(np.abs(F_all.reshape(nx, ny, nz) - F_avg_3d)[int_mask])
    max_diff_int_sq = np.max((np.abs(F_all.reshape(nx, ny, nz) - F_avg_3d)**2)[int_mask])
    results["integer_hkl_verification"] = {
        "max_abs_F_minus_Favg_at_integer": float(max_diff_int),
        "max_abs_F_minus_Favg_squared_at_integer": float(max_diff_int_sq),
        "max_discus_diffuse_at_integer": float(discus_diffuse[int_mask].max()),
    }
    print(f"\n  Integer-hkl verification:")
    print(f"    max |F - F_avg| at integer hkl: {max_diff_int:.4e}")
    print(f"    max |F - F_avg|^2 at integer hkl: {max_diff_int_sq:.4e}")
    print(f"    max DISCUS diffuse at integer hkl: {discus_diffuse[int_mask].max():.4e}")
    
    # Observed total/diffuse relationship
    actual_noninteger = ~int_mask
    results["observed_noninteger_total_diffuse_rel_L2"] = float(
        np.linalg.norm((discus_total - discus_diffuse)[actual_noninteger]) /
        np.linalg.norm(discus_total[actual_noninteger])
    )
    results["observed_max_integer_diffuse"] = float(discus_diffuse[int_mask].max())
    
    if output_json:
        with open(output_json, "w") as f:
            json.dump(results, f, indent=2)
        print(f"\nResults written to {output_json}")
    
    return results


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Independent structure-factor benchmark (v3)")
    parser.add_argument("--stru", required=True, help="Path to .stru file")
    parser.add_argument("--total", required=True, help="Path to DISCUS total HDF5")
    parser.add_argument("--diffuse", required=True, help="Path to DISCUS diffuse HDF5")
    parser.add_argument("--output", default=None, help="Output JSON path")
    
    args = parser.parse_args()
    
    results = run_full_benchmark(
        args.stru, args.total, args.diffuse,
        output_json=args.output
    )
