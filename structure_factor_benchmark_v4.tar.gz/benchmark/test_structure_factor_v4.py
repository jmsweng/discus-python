#!/usr/bin/env python3
"""
Regression tests for the independent structure-factor benchmark (v4).

Tests:
1. Analytic finite geometric series (interference factor)
2. Basis occupancies (8 sites, 512 each)
3. Off-grid diffuse intensity (previously unsampled points)
4. Original commensurate grid (65^3, 1/8-rlu)
5. Integer-hkl Bragg-node cancellation
"""

import numpy as np
import sys
from pathlib import Path

# Add the benchmark script to the path
sys.path.insert(0, str(Path(__file__).parent))

from independent_structure_factor_v4 import (
    interference_factor,
    compute_site_occupancies,
    calculate_structure_factor,
    calculate_average_structure_factor_site_resolved,
    f_xray_Ga,
    f_xray_As,
    read_stru,
)


def test_interference_factor_integer():
    """Test: interference factor at integer hkl should be 8 (real)."""
    # At d=0, the sum is 8 (all terms are 1)
    result = interference_factor(np.array([0.0]))
    assert np.allclose(result, 8.0 + 0j, atol=1e-10), f"Failed: {result}"
    
    # At d=1, the sum is 8 (all terms are 1)
    result = interference_factor(np.array([1.0]))
    assert np.allclose(result, 8.0 + 0j, atol=1e-10), f"Failed: {result}"
    
    # At d=4, the sum is 8 (all terms are 1)
    result = interference_factor(np.array([4.0]))
    assert np.allclose(result, 8.0 + 0j, atol=1e-10), f"Failed: {result}"
    
    print("PASS: interference_factor at integer hkl = 8")


def test_interference_factor_commensurate_offgrid():
    """Test: interference factor at non-integer multiples of 1/8 should be 0."""
    # At d=0.125 (1/8), the sum should be 0
    result = interference_factor(np.array([0.125]))
    assert np.allclose(result, 0.0 + 0j, atol=1e-10), f"Failed: {result}"
    
    # At d=0.25 (2/8), the sum should be 0
    result = interference_factor(np.array([0.25]))
    assert np.allclose(result, 0.0 + 0j, atol=1e-10), f"Failed: {result}"
    
    # At d=0.375 (3/8), the sum should be 0
    result = interference_factor(np.array([0.375]))
    assert np.allclose(result, 0.0 + 0j, atol=1e-10), f"Failed: {result}"
    
    print("PASS: interference_factor at commensurate off-grid = 0")


def test_interference_factor_generic_offgrid():
    """Test: interference factor at generic off-grid hkl should be nonzero complex."""
    # At d=0.05, the sum should be a nonzero complex number
    result = interference_factor(np.array([0.05]))
    assert abs(result[0]) > 1e-6, f"Failed: {result} (expected nonzero)"
    # The magnitude should be less than 8 (not a Bragg peak)
    assert abs(result[0]) < 8.0, f"Failed: {result} (expected < 8)"
    
    # At d=0.1, the sum should be a nonzero complex number
    result = interference_factor(np.array([0.1]))
    assert abs(result[0]) > 1e-6, f"Failed: {result} (expected nonzero)"
    
    print(f"PASS: interference_factor at generic off-grid = {result[0]:.4e} (nonzero)")


def test_basis_occupancies():
    """Test: basis occupancies should have 8 sites, 512 each."""
    # Create a synthetic structure with known occupancies
    # 8 basis positions, each with 512 sites
    # Basis 0: all GA
    # Basis 1: all AS
    # etc.
    
    species_list = []
    r_frac_list = []
    
    # 8 basis positions
    basis_positions = [
        (0.0, 0.0, 0.0),
        (0.0, 0.5, 0.5),
        (0.25, 0.25, 0.25),
        (0.25, 0.75, 0.75),
        (0.5, 0.0, 0.5),
        (0.5, 0.5, 0.0),
        (0.75, 0.25, 0.75),
        (0.75, 0.75, 0.25),
    ]
    
    # Each basis has 512 sites
    for i, bp in enumerate(basis_positions):
        for n in range(512):
            # Cell indices: -4 to 3
            cell = n // 8  # 0 to 63, but we only need -4 to 3
            # Actually, let's just use the basis position repeated
            species_list.append('GA' if i < 4 else 'AS')
            r_frac_list.append((bp[0] + 0.0, bp[1] + 0.0, bp[2] + 0.0))
    
    species = np.array(species_list)
    r_frac = np.array(r_frac_list, dtype=float)
    
    occupancies = compute_site_occupancies(species, r_frac)
    
    # Verify: 8 basis positions
    assert len(occupancies) == 8, f"Failed: {len(occupancies)} basis positions"
    
    # Verify: each has 512 sites
    for bp, (p_Ga, p_As, count) in occupancies.items():
        assert count == 512, f"Failed: {bp} has {count} sites"
    
    # Verify: first 4 are all GA, last 4 are all AS
    for i, bp in enumerate(basis_positions):
        p_Ga, p_As, _ = occupancies[bp]
        if i < 4:
            assert p_Ga == 1.0, f"Failed: {bp} p_Ga={p_Ga}"
            assert p_As == 0.0, f"Failed: {bp} p_As={p_As}"
        else:
            assert p_Ga == 0.0, f"Failed: {bp} p_Ga={p_Ga}"
            assert p_As == 1.0, f"Failed: {bp} p_As={p_As}"
    
    print("PASS: basis_occupancies (8 sites, 512 each)")


def test_offgrid_diffuse_intensity():
    """Test: off-grid diffuse intensity at previously unsampled points."""
    # Read the frozen structure
    stru_path = Path(__file__).parent / "C1_frozen.stru"
    species, r_frac, biso = read_stru(stru_path)
    
    # Compute site occupancies
    occupancies = compute_site_occupancies(species, r_frac)
    
    a = 5.6537  # lattice constant
    
    # Test points from the review
    test_points = [
        (0.05, 0.0, 0.0),
        (0.10, 0.0, 0.0),
        (0.10, 0.15, 0.07),
    ]
    
    for hkl_test in test_points:
        hkl_arr = np.array([hkl_test])
        
        F = calculate_structure_factor(
            hkl_arr, r_frac, f_xray_Ga, f_xray_As, species, biso, a
        )
        F_avg = calculate_average_structure_factor_site_resolved(
            hkl_arr, occupancies, f_xray_Ga, f_xray_As, a, biso=1.0, n_min=-4, n_max=3
        )
        I_diff = np.abs(F - F_avg)**2
        
        # The diffuse intensity should be nonzero and finite
        assert 0 < I_diff[0] < 1e10, f"Failed: {hkl_test} I_diff={I_diff[0]}"
        
        # The interference factor should be nonzero (not a Bragg peak)
        h_int = interference_factor(np.array([hkl_test[0]]))
        k_int = interference_factor(np.array([hkl_test[1]]))
        l_int = interference_factor(np.array([hkl_test[2]]))
        interference = h_int[0] * k_int[0] * l_int[0]
        assert abs(interference) > 1e-6, f"Failed: {hkl_test} interference={interference}"
        
        print(f"PASS: off-grid diffuse at {hkl_test} = {I_diff[0]:.4e}")


def test_integer_hkl_cancellation():
    """Test: |F - F_avg| at integer hkl should be ~0."""
    # Read the frozen structure
    stru_path = Path(__file__).parent / "C1_frozen.stru"
    species, r_frac, biso = read_stru(stru_path)
    
    # Compute site occupancies
    occupancies = compute_site_occupancies(species, r_frac)
    
    a = 5.6537  # lattice constant
    
    # Test integer hkl points
    test_points = [
        (0.0, 0.0, 0.0),
        (1.0, 0.0, 0.0),
        (0.0, 1.0, 0.0),
        (1.0, 1.0, 0.0),
        (2.0, 1.0, 1.0),
    ]
    
    for hkl_test in test_points:
        hkl_arr = np.array([hkl_test])
        
        F = calculate_structure_factor(
            hkl_arr, r_frac, f_xray_Ga, f_xray_As, species, biso, a
        )
        F_avg = calculate_average_structure_factor_site_resolved(
            hkl_arr, occupancies, f_xray_Ga, f_xray_As, a, biso=1.0, n_min=-4, n_max=3
        )
        diff = np.abs(F - F_avg)
        
        # At integer hkl, the difference should be ~0
        assert diff[0] < 1e-8, f"Failed: {hkl_test} |F-F_avg|={diff[0]}"
        
        print(f"PASS: integer-hkl cancellation at {hkl_test} = {diff[0]:.4e}")


def test_form_factors():
    """Test: form factors should give f(0) ≈ Z."""
    f_Ga_0 = f_xray_Ga(np.array([0.0]))[0]
    f_As_0 = f_xray_As(np.array([0.0]))[0]
    
    # f(0) should be close to Z (31 for Ga, 33 for As)
    assert abs(f_Ga_0 - 31.0) < 0.5, f"Failed: f_Ga(0)={f_Ga_0}"
    assert abs(f_As_0 - 33.0) < 0.5, f"Failed: f_As(0)={f_As_0}"
    
    print(f"PASS: form factors f_Ga(0)={f_Ga_0:.4f}, f_As(0)={f_As_0:.4f}")


if __name__ == "__main__":
    print("=" * 60)
    print("REGRESSION TESTS — INDEPENDENT STRUCTURE-FACTOR BENCHMARK (v4)")
    print("=" * 60)
    
    test_form_factors()
    test_interference_factor_integer()
    test_interference_factor_commensurate_offgrid()
    test_interference_factor_generic_offgrid()
    test_basis_occupancies()
    test_offgrid_diffuse_intensity()
    test_integer_hkl_cancellation()
    
    print("\n" + "=" * 60)
    print("ALL TESTS PASSED")
    print("=" * 60)
