#!/usr/bin/env python3
"""
Independent kinematic structure-factor calculation for DISCUS 6.23.01 validation.

CORRECTED VERSION (v4) — addresses v3 review findings:

1. Coordinates: The .stru file stores positions in BASE-CELL FRACTIONAL units.
   Use them directly in exp(2*pi*i * h.r). Do NOT divide by the lattice constant.

2. Form factors: Uses published Gemmi IT92 (International Tables 1992)
   X-ray scattering factors for Ga and As.

3. Debye-Waller: Includes the isotropic Debye-Waller factor exp(-Biso*s^2)
   where s = sin(theta)/lambda = |hkl| / (2*a) for cubic crystals.
   All atoms in C1_frozen.stru have Biso = 1.0 A^2.

4. Average structure: Uses a SITE-RESOLVED occupancy model with the CORRECT
   finite-supercell interference factor.

   The 4096-atom supercell has 8 distinct crystallographic basis positions,
   each repeated 512 times across an 8x8x8 supercell with cell indices
   n = -4, -3, ..., 3 (NOT n = 0, 1, ..., 7).

   F_avg(hkl) = exp(-Biso*s^2) * sum_b [f_avg,b(s) * exp(2pi*i * hkl.dot(b))]
              * product_{d in {h,k,l}} sum_{n=-4}^{3} exp(2pi*i * d * n)

   where:
   - b iterates over the 8 basis positions
   - f_avg,b(s) = p_Ga,b * f_Ga(s) + p_As,b * f_As(s)
   - s = |hkl| / (2*a)
   - The product term is the 8-cell translation interference factor
   - The sum MUST use n = -4...3 to match the actual origin of the saved model

   The interference factor sum_{n=-4}^{3} exp(2pi*i*d*n) is:
   - 8 if d is an integer (Bragg condition)
   - 0 if d is a non-integer multiple of 1/8 (commensurate off-grid)
   - A NONZERO COMPLEX NUMBER for generic off-grid hkl

   This is a genuine amplitude-level average-structure model for the saved,
   periodically repeated 8-site basis. It is NOT a universal ensemble average.

Conventions:
- hkl are in units of the reciprocal lattice (basecell_fractional)
- s = |hkl| / (2*a)  [sin(theta)/lambda for cubic crystals]
- f_j(s) is the X-ray atomic scattering factor (electrons)
- Total intensity I(hkl) = |F(hkl)|^2
- F(hkl) = sum_j f_j(s) * exp(-Biso_j * s^2) * exp(2*pi*i * h.r_j)
"""

import numpy as np
import h5py
import os
import json
import sys
from typing import Tuple, Dict

try:
    import gemmi
    HAS_GEMMI = True
except ImportError:
    HAS_GEMMI = False

# ---------------------------------------------------------------------------
# X-ray atomic scattering factors (IT92 / International Tables 1992)
# ---------------------------------------------------------------------------

IT92_GA = {
    "a": [15.2354, 6.7006, 4.3591, 2.9623],
    "b": [3.0669, 0.2412, 10.7805, 61.4135],
    "c": 1.7189,
}

IT92_AS = {
    "a": [16.6723, 6.0701, 3.4313, 4.2779],
    "b": [2.6345, 0.2647, 12.9479, 47.7972],
    "c": 2.531,
}


def f_xray_Ga(s: np.ndarray) -> np.ndarray:
    """
    X-ray scattering factor for Gallium (Ga, Z=31).
    Uses the IT92 parameterization. f(0) = 30.9763.
    """
    if HAS_GEMMI:
        it92 = gemmi.Element('Ga').it92
        a = np.array([float(x) for x in it92.a])
        b = np.array([float(x) for x in it92.b])
        c = float(it92.c)
    else:
        a = np.array(IT92_GA["a"])
        b = np.array(IT92_GA["b"])
        c = IT92_GA["c"]
    
    s2 = s**2
    f = np.zeros_like(s2)
    for ai, bi in zip(a, b):
        f += ai * np.exp(-bi * s2)
    f += c
    return f


def f_xray_As(s: np.ndarray) -> np.ndarray:
    """
    X-ray scattering factor for Arsenic (As, Z=33).
    Uses the IT92 parameterization. f(0) = 32.9826.
    """
    if HAS_GEMMI:
        it92 = gemmi.Element('As').it92
        a = np.array([float(x) for x in it92.a])
        b = np.array([float(x) for x in it92.b])
        c = float(it92.c)
    else:
        a = np.array(IT92_AS["a"])
        b = np.array(IT92_AS["b"])
        c = IT92_AS["c"]
    
    s2 = s**2
    f = np.zeros_like(s2)
    for ai, bi in zip(a, b):
        f += ai * np.exp(-bi * s2)
    f += c
    return f


# ---------------------------------------------------------------------------
# Structure file reader
# ---------------------------------------------------------------------------

def read_stru(path: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Read a DISCUS .stru file.
    
    IMPORTANT: The positions in the .stru file are in BASE-CELL FRACTIONAL
    units, NOT Cartesian Angstroms. Use them directly as fractional coordinates.
    
    RESTRICTION: This reader assumes all occupations are 1 and only GA/AS
    are present. This matches the frozen C1 input but should be validated
    or documented as a restricted reader for other structures.
    
    Returns:
        species: array of species labels (str)
        r_frac: (N, 3) array of fractional coordinates (base-cell units)
        biso: (N,) array of Biso values (A^2)
    """
    species_list = []
    r_frac_list = []
    biso_list = []
    
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith(('title', 'spcgr', 'cell', 'format', 'atoms')):
                continue
            parts = line.split()
            if len(parts) < 4:
                continue
            species = parts[0].upper()
            if species not in ('GA', 'AS'):
                continue
            # Parse the next 4 values: x, y, z, Biso
            # These are comma-separated; strip trailing commas
            vals = []
            for tok in parts[1:5]:
                try:
                    vals.append(float(tok.rstrip(',')))
                except ValueError:
                    break
            if len(vals) < 4:
                continue
            r_frac_list.append(vals[:3])
            biso_list.append(vals[3])
            species_list.append(species)
    
    return (np.array(species_list),
            np.array(r_frac_list, dtype=float),
            np.array(biso_list, dtype=float))


# ---------------------------------------------------------------------------
# Site-resolved average structure factor (CORRECTED v4)
# ---------------------------------------------------------------------------

def compute_site_occupancies(
    species: np.ndarray,
    r_frac: np.ndarray
) -> Dict[tuple, Tuple[float, float, int]]:
    """
    Compute site-resolved occupancies for the 8 basis positions.
    
    The 4096-atom supercell has 8 distinct crystallographic basis positions,
    each repeated 512 times across an 8x8x8 supercell.
    
    Returns:
        dict mapping basis position (tuple of 3 floats) to (p_Ga, p_As, count)
    """
    N = len(species)
    if N != 4096:
        raise ValueError(f"Expected 4096 atoms, got {N}")
    
    # Group sites by their fractional part (basis position)
    # The basis positions are at quarter-cell increments
    basis_positions = np.round(r_frac % 1.0, decimals=4)
    
    # Find unique basis positions
    unique_basis = []
    occupancies = {}
    
    for i in range(N):
        bp = tuple(basis_positions[i])
        if bp not in occupancies:
            occupancies[bp] = {"GA": 0, "AS": 0}
            unique_basis.append(bp)
        occupancies[bp][species[i]] += 1
    
    # Verify: 8 unique basis positions, each with 512 sites
    if len(unique_basis) != 8:
        raise ValueError(f"Expected 8 basis positions, got {len(unique_basis)}")
    
    result = {}
    for bp in unique_basis:
        counts = occupancies[bp]
        total = counts["GA"] + counts["AS"]
        if total != 512:
            raise ValueError(f"Basis {bp}: expected 512 sites, got {total}")
        p_Ga = counts["GA"] / 512.0
        p_As = counts["AS"] / 512.0
        result[bp] = (p_Ga, p_As, total)
    
    return result


def interference_factor(d: np.ndarray, n_min: int = -4, n_max: int = 3) -> np.ndarray:
    """
    Compute the finite-supercell interference factor.
    
    The sum is: sum_{n=n_min}^{n_max} exp(2*pi*i * d * n)
    
    For the saved 8x8x8 supercell with cell indices n = -4, -3, ..., 3:
    - 8 if d is an integer (Bragg condition)
    - 0 if d is a non-integer multiple of 1/8 (commensurate off-grid)
    - A NONZERO COMPLEX NUMBER for generic off-grid hkl
    
    This is the CORRECT expression. The v3 code incorrectly used:
    interference = np.where(is_integer, n_cells**3, 0.0)
    which is only valid at hkl sampled in multiples of 1/8.
    
    Args:
        d: array of hkl component values
        n_min: minimum cell index (default: -4)
        n_max: maximum cell index (default: 3)
    
    Returns:
        Complex array of interference factors
    """
    n = np.arange(n_min, n_max + 1)  # -4, -3, ..., 3
    # Phase: 2*pi*i * d * n for each n
    # d is (M,), n is (8,) -> result is (M, 8)
    phase = 2.0 * np.pi * d[:, np.newaxis] * n[np.newaxis, :]
    # Sum over n
    return np.sum(np.exp(1j * phase), axis=1)


def calculate_average_structure_factor_site_resolved(
    hkl: np.ndarray,
    basis_occupancies: Dict[tuple, Tuple[float, float, int]],
    f_Ga_fn,
    f_As_fn,
    a: float,
    biso: float = 1.0,
    n_min: int = -4,
    n_max: int = 3
) -> np.ndarray:
    """
    Calculate the site-resolved average structure factor <F>(hkl).
    
    For a periodically repeated 8-site basis with empirical occupancies:
    
    F_avg(hkl) = exp(-Biso*s^2)
        * sum_b [f_avg,b(s) * exp(2pi*i * hkl.dot(b))]
        * product_{d in {h,k,l}} sum_{n=n_min}^{n_max} exp(2pi*i * d * n)
    
    where:
    - b iterates over the 8 basis positions
    - f_avg,b(s) = p_Ga,b * f_Ga(s) + p_As,b * f_As(s)
    - s = |hkl| / (2*a)
    - n_min = -4, n_max = 3 (matching the actual origin of the saved model)
    
    The interference factor sum_{n=-4}^{3} exp(2pi*i*d*n) is:
    - 8 if d is an integer
    - 0 if d is a non-integer multiple of 1/8
    - A NONZERO COMPLEX NUMBER for generic off-grid hkl
    
    IMPORTANT: The v3 code incorrectly used a blanket integer-hkl mask:
    interference = np.where(is_integer, n_cells**3, 0.0)
    This is only valid at hkl sampled in multiples of 1/8.
    
    Args:
        hkl: (M, 3) array of hkl values
        basis_occupancies: dict from compute_site_occupancies()
        f_Ga_fn: callable for Ga scattering factor
        f_As_fn: callable for As scattering factor
        a: lattice constant (A)
        biso: Debye-Waller parameter (A^2)
        n_min: minimum cell index (default: -4)
        n_max: maximum cell index (default: 3)
    
    Returns:
        F_avg: (M,) complex array
    """
    M = hkl.shape[0]
    F_avg = np.zeros(M, dtype=complex)
    
    basis_list = list(basis_occupancies.keys())
    
    for start in range(0, M, 32):
        end = min(start + 32, M)
        h_chunk = hkl[start:end]  # (C, 3)
        
        s_chunk = np.linalg.norm(h_chunk, axis=1) / (2.0 * a)  # (C,)
        s2_chunk = s_chunk**2
        dw = np.exp(-biso * s2_chunk)  # (C,)
        
        f_Ga_chunk = f_Ga_fn(s_chunk)  # (C,)
        f_As_chunk = f_As_fn(s_chunk)  # (C,)
        
        # Sum over basis sites
        F_basis = np.zeros(end - start, dtype=complex)
        for bp in basis_list:
            p_Ga, p_As, _ = basis_occupancies[bp]
            f_avg = p_Ga * f_Ga_chunk + p_As * f_As_chunk  # (C,)
            
            # Phase: exp(2pi*i * hkl.dot(bp))
            dot = h_chunk @ np.array(bp)  # (C,)
            phase = 2 * np.pi * dot
            F_basis += f_avg * np.exp(1j * phase)
        
        # CORRECT interference factor: product of complex geometric sums
        # For each hkl component d, compute sum_{n=-4}^{3} exp(2pi*i*d*n)
        # Then multiply the three components together
        h_int = interference_factor(h_chunk[:, 0], n_min, n_max)  # (C,)
        k_int = interference_factor(h_chunk[:, 1], n_min, n_max)  # (C,)
        l_int = interference_factor(h_chunk[:, 2], n_min, n_max)  # (C,)
        
        # Product of the three interference factors
        interference = h_int * k_int * l_int  # (C,)
        
        F_avg[start:end] = dw * F_basis * interference
    
    return F_avg


# ---------------------------------------------------------------------------
# Structure factor calculation (direct sum)
# ---------------------------------------------------------------------------

def calculate_structure_factor(
    hkl: np.ndarray,
    r_frac: np.ndarray,
    f_Ga_fn,
    f_As_fn,
    species: np.ndarray,
    biso: np.ndarray,
    a: float,
    chunk_size: int = 32
) -> np.ndarray:
    """
    Calculate F(hkl) = sum_j f_j(s) * exp(-Biso_j * s^2) * exp(2*pi*i * h.r_j)
    
    where s = |hkl| / (2*a) for cubic crystals.
    """
    M = hkl.shape[0]
    F = np.zeros(M, dtype=complex)
    
    ga_mask = (species == 'GA')
    r_Ga = r_frac[ga_mask]
    biso_Ga = biso[ga_mask]
    r_As = r_frac[~ga_mask]
    biso_As = biso[~ga_mask]
    
    for start in range(0, M, chunk_size):
        end = min(start + chunk_size, M)
        h_chunk = hkl[start:end]
        
        hkl_mag = np.linalg.norm(h_chunk, axis=1)
        s_chunk = hkl_mag / (2.0 * a)
        
        f_Ga_chunk = f_Ga_fn(s_chunk)
        f_As_chunk = f_As_fn(s_chunk)
        
        s2_chunk = s_chunk**2
        dw_Ga = np.exp(-biso_Ga * s2_chunk[:, np.newaxis])
        dw_As = np.exp(-biso_As * s2_chunk[:, np.newaxis])
        
        dot_Ga = h_chunk @ r_Ga.T
        F_Ga_chunk = f_Ga_chunk * np.sum(dw_Ga * np.exp(1j * 2 * np.pi * dot_Ga), axis=1)
        
        dot_As = h_chunk @ r_As.T
        F_As_chunk = f_As_chunk * np.sum(dw_As * np.exp(1j * 2 * np.pi * dot_As), axis=1)
        
        F[start:end] = F_Ga_chunk + F_As_chunk
    
    return F


def build_hkl_grid(
    nx: int, ny: int, nz: int,
    hmin: float, step: float
) -> np.ndarray:
    """Build a 3D hkl grid."""
    h_vals = np.arange(nx) * step + hmin
    k_vals = np.arange(ny) * step + hmin
    l_vals = np.arange(nz) * step + hmin
    
    H, K, L = np.meshgrid(h_vals, k_vals, l_vals, indexing='ij')
    return np.stack([H, K, L], axis=-1)


# ---------------------------------------------------------------------------
# Comparison metrics
# ---------------------------------------------------------------------------

def compute_metrics(independent: np.ndarray, discus: np.ndarray) -> dict:
    """Compute comparison metrics."""
    diff = np.abs(independent - discus)
    l2_diff = np.sqrt(np.sum(diff**2))
    l2_discus = np.sqrt(np.sum(discus**2))
    rel_l2 = l2_diff / l2_discus if l2_discus != 0 else float('inf')
    
    if independent.std() > 0 and discus.std() > 0:
        pearson = np.corrcoef(independent.flatten(), discus.flatten())[0, 1]
    else:
        pearson = float('nan')
    
    nonzero = np.abs(discus) > 1e-10
    if nonzero.any():
        scale_ratio = np.mean(independent[nonzero] / discus[nonzero])
    else:
        scale_ratio = float('nan')
    
    max_idx = np.unravel_index(np.argmax(diff), diff.shape)
    
    return {
        "max_abs_diff": float(diff.max()),
        "mean_abs_diff": float(diff.mean()),
        "rel_l2": float(rel_l2),
        "pearson": float(pearson),
        "scale_ratio": float(scale_ratio),
        "independent_max": float(independent.max()),
        "discus_max": float(discus.max()),
        "independent_mean": float(independent.mean()),
        "discus_mean": float(discus.mean()),
        "largest_residual_index": [int(x) for x in max_idx],
    }


# ---------------------------------------------------------------------------
# Main benchmark
# ---------------------------------------------------------------------------

def run_full_benchmark(
    stru_path: str,
    total_h5: str,
    diffuse_h5: str,
    output_json: str = None
) -> dict:
    """Run the full benchmark (total + diffuse) using IT92 form factors."""
    print(f"\n{'='*60}")
    print(f"INDEPENDENT STRUCTURE-FACTOR BENCHMARK (v4 — CORRECT INTERFERENCE)")
    print(f"{'='*60}")
    
    # Read structure
    species, r_frac, biso = read_stru(stru_path)
    N = len(species)
    n_Ga = np.sum(species == 'GA')
    n_As = np.sum(species == 'AS')
    print(f"Atoms: {N} ({n_Ga} GA, {n_As} AS)")
    print(f"Coordinates: base-cell fractional units")
    print(f"  r_frac range: [{r_frac.min():.4f}, {r_frac.max():.4f}]")
    print(f"  Biso range: [{biso.min():.4f}, {biso.max():.4f}] A^2")
    
    # Compute site-resolved occupancies
    print("\nComputing site-resolved occupancies...")
    occupancies = compute_site_occupancies(species, r_frac)
    print(f"  Basis positions: {len(occupancies)}")
    for bp, (p_Ga, p_As, count) in sorted(occupancies.items()):
        print(f"    {bp}: GA={p_Ga:.4f} ({int(p_Ga*512)}/512), AS={p_As:.4f} ({int(p_As*512)}/512)")
    
    # Read DISCUS metadata
    with h5py.File(total_h5, "r") as h:
        data = h["entry"]["data"]
        a = float(data["unit_cell_lengths"][0])
        nx, ny, nz = data["data_dimension"][()]
        hmin = float(data["data_corner"][0])
        step = float(data["data_increment_vector"][0, 0])
        discus_total = data["data_values"][:]
    
    with h5py.File(diffuse_h5, "r") as h:
        discus_diffuse = h["entry"]["data"]["data_values"][:]
    
    print(f"\nUnit cell: a = {a:.6f} A")
    print(f"Grid: {nx}x{ny}x{nz}, hmin={hmin}, step={step}")
    
    # Build hkl grid
    hkl_grid = build_hkl_grid(nx, ny, nz, hmin, step)
    hkl_flat = hkl_grid.reshape(-1, 3)
    
    # Form factor functions
    f_Ga_fn = f_xray_Ga
    f_As_fn = f_xray_As
    
    f_Ga_0 = f_Ga_fn(np.array([0.0]))[0]
    f_As_0 = f_As_fn(np.array([0.0]))[0]
    print(f"Form factors (IT92): f_Ga(0)={f_Ga_0:.4f}, f_As(0)={f_As_0:.4f}")
    
    # Calculate F(hkl)
    print(f"\nCalculating F(hkl) for {len(hkl_flat)} grid points...")
    F_all = calculate_structure_factor(
        hkl_flat, r_frac, f_Ga_fn, f_As_fn, species, biso, a, chunk_size=32
    )
    
    # Total intensity
    I_total = np.abs(F_all)**2
    I_total = I_total.reshape(nx, ny, nz)
    print(f"  Total: max={I_total.max():.4e}, min={I_total.min():.4e}")
    
    # Site-resolved average structure factor (CORRECT interference)
    print("Calculating site-resolved average structure factor <F>(hkl)...")
    F_avg = calculate_average_structure_factor_site_resolved(
        hkl_flat, occupancies, f_Ga_fn, f_As_fn, a, biso=1.0, n_min=-4, n_max=3
    )
    
    # Amplitude-based diffuse: |F(hkl) - <F>(hkl)|^2
    I_diff_amplitude = np.abs(F_all - F_avg)**2
    I_diff_amplitude = I_diff_amplitude.reshape(nx, ny, nz)
    print(f"  Diffuse (amplitude): max={I_diff_amplitude.max():.4e}, min={I_diff_amplitude.min():.4e}")
    
    # Compare
    results = {}
    for name, ind, disc in [
        ("total", I_total, discus_total),
        ("diffuse_amplitude", I_diff_amplitude, discus_diffuse),
    ]:
        metrics = compute_metrics(ind, disc)
        hkl_at_max = hkl_grid[tuple(metrics["largest_residual_index"])]
        
        discus_max_idx = np.unravel_index(np.argmax(disc), disc.shape)
        discus_peak_hkl = hkl_grid[discus_max_idx]
        discus_peak_val = disc[discus_max_idx]
        ind_peak_val = ind[discus_max_idx]
        
        metrics["largest_residual_hkl"] = [float(x) for x in hkl_at_max]
        metrics["discus_peak_hkl"] = [float(x) for x in discus_peak_hkl]
        metrics["discus_peak_value"] = float(discus_peak_val)
        metrics["independent_at_discus_peak"] = float(ind_peak_val)
        
        results[name] = metrics
        
        print(f"\n  {name}: rel_L2={metrics['rel_l2']:.6e}, pearson={metrics['pearson']:.8f}, "
              f"max_diff={metrics['max_abs_diff']:.4e} at hkl={hkl_at_max}")
        print(f"    DISCUS peak: {discus_peak_val:.4e} at hkl={discus_peak_hkl}, "
              f"independent at same point: {ind_peak_val:.4e}")
    
    # (0,0,0) comparison
    origin_idx = (32, 32, 32)
    results["origin_comparison"] = {
        "discus": float(discus_total[origin_idx]),
        "independent": float(I_total[origin_idx]),
        "ratio": float(I_total[origin_idx] / discus_total[origin_idx]) if discus_total[origin_idx] != 0 else float('nan'),
    }
    print(f"\n  (0,0,0): DISCUS={discus_total[origin_idx]:.4e}, "
          f"independent={I_total[origin_idx]:.4e}, "
          f"ratio={results['origin_comparison']['ratio']:.6f}")
    
    # Example hkl point
    example_idx = (31, 32, 32)
    results["example_hkl_(-0.125,0,0)"] = {
        "discus": float(discus_total[example_idx]),
        "independent": float(I_total[example_idx]),
        "ratio": float(I_total[example_idx] / discus_total[example_idx]) if discus_total[example_idx] != 0 else float('nan'),
    }
    print(f"  (-0.125,0,0): DISCUS={discus_total[example_idx]:.4e}, "
          f"independent={I_total[example_idx]:.4e}, "
          f"ratio={results['example_hkl_(-0.125,0,0)']['ratio']:.6f}")
    
    # Verify: |F - F_avg| at integer hkl should be ~0
    int_mask = np.zeros((nx, ny, nz), dtype=bool)
    for i in np.arange(0, 65, 8):
        for j in np.arange(0, 65, 8):
            for k in np.arange(0, 65, 8):
                int_mask[i, j, k] = True
    
    F_avg_3d = F_avg.reshape(nx, ny, nz)
    max_diff_int = np.max(np.abs(F_all.reshape(nx, ny, nz) - F_avg_3d)[int_mask])
    max_diff_int_sq = np.max((np.abs(F_all.reshape(nx, ny, nz) - F_avg_3d)**2)[int_mask])
    results["integer_hkl_verification"] = {
        "max_abs_F_minus_Favg_at_integer": float(max_diff_int),
        "max_abs_F_minus_Favg_squared_at_integer": float(max_diff_int_sq),
        "max_discus_diffuse_at_integer": float(discus_diffuse[int_mask].max()),
    }
    print(f"\n  Integer-hkl verification:")
    print(f"    max |F - F_avg| at integer hkl: {max_diff_int:.4e}")
    print(f"    max |F - F_avg|^2 at integer hkl: {max_diff_int_sq:.4e}")
    print(f"    max DISCUS diffuse at integer hkl: {discus_diffuse[int_mask].max():.4e}")
    
    # Observed total/diffuse relationship
    actual_noninteger = ~int_mask
    results["observed_noninteger_total_diffuse_rel_L2"] = float(
        np.linalg.norm((discus_total - discus_diffuse)[actual_noninteger]) /
        np.linalg.norm(discus_total[actual_noninteger])
    )
    results["observed_max_integer_diffuse"] = float(discus_diffuse[int_mask].max())
    
    # Off-grid verification (NEW in v4)
    # Test a few off-grid points to verify the interference factor is correct
    print("\n  Off-grid verification (v4):")
    off_grid_points = [
        (0.05, 0.0, 0.0),
        (0.10, 0.0, 0.0),
        (0.10, 0.15, 0.07),
    ]
    results["off_grid_verification"] = {}
    for hkl_test in off_grid_points:
        hkl_test_arr = np.array([hkl_test])
        F_test = calculate_structure_factor(
            hkl_test_arr, r_frac, f_Ga_fn, f_As_fn, species, biso, a
        )
        F_avg_test = calculate_average_structure_factor_site_resolved(
            hkl_test_arr, occupancies, f_Ga_fn, f_As_fn, a, biso=1.0, n_min=-4, n_max=3
        )
        I_diff_test = np.abs(F_test - F_avg_test)**2
        # Interference factor at this point
        h_int = interference_factor(np.array([hkl_test[0]]))
        k_int = interference_factor(np.array([hkl_test[1]]))
        l_int = interference_factor(np.array([hkl_test[2]]))
        results["off_grid_verification"][str(hkl_test)] = {
            "I_diff": float(I_diff_test[0]),
            "interference_h_real": float(h_int[0].real),
            "interference_h_imag": float(h_int[0].imag),
            "interference_k_real": float(k_int[0].real),
            "interference_k_imag": float(k_int[0].imag),
            "interference_l_real": float(l_int[0].real),
            "interference_l_imag": float(l_int[0].imag),
        }
        print(f"    hkl={hkl_test}: I_diff={I_diff_test[0]:.4e}, "
              f"|interference|={abs(h_int[0]*k_int[0]*l_int[0]):.4e}")
    
    if output_json:
        with open(output_json, "w") as f:
            json.dump(results, f, indent=2)
        print(f"\nResults written to {output_json}")
    
    return results


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Independent structure-factor benchmark (v4)")
    parser.add_argument("--stru", required=True, help="Path to .stru file")
    parser.add_argument("--total", required=True, help="Path to DISCUS total HDF5")
    parser.add_argument("--diffuse", required=True, help="Path to DISCUS diffuse HDF5")
    parser.add_argument("--output", default=None, help="Output JSON path")
    
    args = parser.parse_args()
    
    results = run_full_benchmark(
        args.stru, args.total, args.diffuse,
        output_json=args.output
    )
