#!/usr/bin/env python3
"""
Independent kinematic structure-factor calculation for DISCUS 6.23.01 validation.

CORRECTED VERSION (v2) — addresses independent review findings:

1. Coordinates: The .stru file stores positions in BASE-CELL FRACTIONAL units,
   NOT Cartesian Angstroms. Use them directly in exp(2*pi*i * h.r).
   Do NOT divide by the lattice constant.

2. Form factors: Uses published Gemmi IT92 (International Tables 1992)
   X-ray scattering factors for Ga and As. These are traceable, published
   coefficients, not ad-hoc approximations.

3. Debye-Waller: Includes the isotropic Debye-Waller factor exp(-Biso*s^2)
   where s = sin(theta)/lambda = |hkl| / (2*a) for cubic crystals.
   All atoms in C1_frozen.stru have Biso = 1.0 A^2.

4. Diffuse: Implements amplitude-based average-structure subtraction
   |F(hkl) - <F>(hkl)|^2 where <F> is the structure factor of the average
   crystal (fractional occupancies). Also compares against the observed
   integer-hkl mask behavior on the sampled grid.

Conventions:
- hkl are in units of the reciprocal lattice (basecell_fractional)
- s = |hkl| / (2*a)  [sin(theta)/lambda for cubic crystals]
- f_j(s) is the X-ray atomic scattering factor (electrons)
- Total intensity I(hkl) = |F(hkl)|^2
- F(hkl) = sum_j f_j(s) * exp(-Biso_j * s^2) * exp(2*pi*i * h.r_j)

The .stru file contains positions in base-cell fractional units.
Use them directly as r_frac in the structure factor calculation.
"""

import numpy as np
import h5py
import os
import json
import sys
from typing import Tuple

try:
    import gemmi
    HAS_GEMMI = True
except ImportError:
    HAS_GEMMI = False

# ---------------------------------------------------------------------------
# X-ray atomic scattering factors (IT92 / International Tables 1992)
# ---------------------------------------------------------------------------

# Fallback coefficients if gemmi is not available.
# These are the Gemmi IT92 coefficients (same as gemmi.Element(symbol).it92).
# f(s) = sum_n a_n * exp(-b_n * s^2) + c
# where s = sin(theta)/lambda = |hkl| / (2*a) for cubic crystals.

IT92_GA = {
    "a": [15.2354, 6.7006, 4.3591, 2.9623],
    "b": [3.0669, 0.2412, 10.7805, 61.4135],
    "c": 1.7189,
}

IT92_AS = {
    "a": [16.6723, 6.0701, 3.4313, 4.2779],
    "b": [2.6345, 0.2647, 12.9479, 47.7972],
    "c": 2.531,
}


def f_xray_Ga(s: np.ndarray) -> np.ndarray:
    """
    X-ray scattering factor for Gallium (Ga, Z=31).
    
    Uses the IT92 (International Tables 1992) parameterization via Gemmi.
    f(s) = sum_n a_n * exp(-b_n * s^2) + c
    where s = sin(theta)/lambda = |hkl| / (2*a) for cubic crystals.
    
    f(0) = 30.9763 (approximately Z=31)
    """
    if HAS_GEMMI:
        it92 = gemmi.Element('Ga').it92
        a = np.array([float(x) for x in it92.a])
        b = np.array([float(x) for x in it92.b])
        c = float(it92.c)
    else:
        a = np.array(IT92_GA["a"])
        b = np.array(IT92_GA["b"])
        c = IT92_GA["c"]
    
    s2 = s**2
    f = np.zeros_like(s2)
    for ai, bi in zip(a, b):
        f += ai * np.exp(-bi * s2)
    f += c
    return f


def f_xray_As(s: np.ndarray) -> np.ndarray:
    """
    X-ray scattering factor for Arsenic (As, Z=33).
    
    Uses the IT92 (International Tables 1992) parameterization via Gemmi.
    f(s) = sum_n a_n * exp(-b_n * s^2) + c
    where s = sin(theta)/lambda = |hkl| / (2*a) for cubic crystals.
    
    f(0) = 32.9826 (approximately Z=33)
    """
    if HAS_GEMMI:
        it92 = gemmi.Element('As').it92
        a = np.array([float(x) for x in it92.a])
        b = np.array([float(x) for x in it92.b])
        c = float(it92.c)
    else:
        a = np.array(IT92_AS["a"])
        b = np.array(IT92_AS["b"])
        c = IT92_AS["c"]
    
    s2 = s**2
    f = np.zeros_like(s2)
    for ai, bi in zip(a, b):
        f += ai * np.exp(-bi * s2)
    f += c
    return f


# ---------------------------------------------------------------------------
# Structure file reader
# ---------------------------------------------------------------------------

def read_stru(path: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Read a DISCUS .stru file.
    
    IMPORTANT: The positions in the .stru file are in BASE-CELL FRACTIONAL
    units, NOT Cartesian Angstroms. Use them directly as fractional coordinates.
    
    Returns:
        species: array of species labels (str)
        r_frac: (N, 3) array of fractional coordinates (base-cell units)
        biso: (N,) array of Biso values (A^2)
    """
    species_list = []
    r_frac_list = []
    biso_list = []
    
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith(('title', 'spcgr', 'cell', 'format', 'atoms')):
                continue
            parts = line.split()
            if len(parts) < 4:
                continue
            species = parts[0].upper()
            if species not in ('GA', 'AS'):
                continue
            # Parse the next 4 values: x, y, z, Biso
            # These are comma-separated; strip trailing commas
            vals = []
            for tok in parts[1:5]:
                try:
                    vals.append(float(tok.rstrip(',')))
                except ValueError:
                    break
            if len(vals) < 4:
                continue
            r_frac_list.append(vals[:3])  # FRACTIONAL coordinates, not Cartesian
            biso_list.append(vals[3])
            species_list.append(species)
    
    return (np.array(species_list),
            np.array(r_frac_list, dtype=float),
            np.array(biso_list, dtype=float))


# ---------------------------------------------------------------------------
# Structure factor calculation
# ---------------------------------------------------------------------------

def calculate_structure_factor(
    hkl: np.ndarray,
    r_frac: np.ndarray,
    f_Ga_fn,
    f_As_fn,
    species: np.ndarray,
    biso: np.ndarray,
    a: float,
    chunk_size: int = 32
) -> np.ndarray:
    """
    Calculate F(hkl) = sum_j f_j(s) * exp(-Biso_j * s^2) * exp(2*pi*i * h.r_j)
    
    where s = |hkl| / (2*a) for cubic crystals.
    
    The .stru file stores positions in base-cell fractional units.
    Use them directly as r_frac in the phase calculation.
    
    Args:
        hkl: (M, 3) array of hkl values (in reciprocal lattice units)
        r_frac: (N, 3) array of fractional coordinates (base-cell units)
        f_Ga_fn: callable that takes s (A^-1) and returns f for Ga
        f_As_fn: callable that takes s (A^-1) and returns f for As
        species: (N,) array of species labels
        biso: (N,) array of Biso values (A^2)
        a: lattice constant in Angstroms
        chunk_size: number of hkl values to process at once
    
    Returns:
        F: (M,) complex array of structure factors
    """
    M = hkl.shape[0]
    F = np.zeros(M, dtype=complex)
    
    ga_mask = (species == 'GA')
    r_Ga = r_frac[ga_mask]
    biso_Ga = biso[ga_mask]
    r_As = r_frac[~ga_mask]
    biso_As = biso[~ga_mask]
    
    for start in range(0, M, chunk_size):
        end = min(start + chunk_size, M)
        h_chunk = hkl[start:end]  # (C, 3)
        
        # s = |hkl| / (2*a) for cubic crystals
        hkl_mag = np.linalg.norm(h_chunk, axis=1)  # (C,)
        s_chunk = hkl_mag / (2.0 * a)  # (C,)
        
        # Scattering factors for this s
        f_Ga_chunk = f_Ga_fn(s_chunk)  # (C,)
        f_As_chunk = f_As_fn(s_chunk)  # (C,)
        
        # Debye-Waller factors: exp(-Biso * s^2)
        s2_chunk = s_chunk**2  # (C,)
        dw_Ga = np.exp(-biso_Ga * s2_chunk[:, np.newaxis])  # (C, N_Ga)
        dw_As = np.exp(-biso_As * s2_chunk[:, np.newaxis])  # (C, N_As)
        
        # Phase for Ga atoms: (C, N_Ga)
        dot_Ga = h_chunk @ r_Ga.T
        phase_Ga = 2 * np.pi * dot_Ga
        exp_Ga = np.exp(1j * phase_Ga)
        # F_Ga[c] = sum_j f_Ga(s_c) * exp(-Biso_j * s_c^2) * exp(i * phase_Ga[c, j])
        F_Ga_chunk = f_Ga_chunk * np.sum(dw_Ga * exp_Ga, axis=1)
        
        # Phase for As atoms: (C, N_As)
        dot_As = h_chunk @ r_As.T
        phase_As = 2 * np.pi * dot_As
        exp_As = np.exp(1j * phase_As)
        F_As_chunk = f_As_chunk * np.sum(dw_As * exp_As, axis=1)
        
        F[start:end] = F_Ga_chunk + F_As_chunk
    
    return F


def calculate_average_structure_factor(
    hkl: np.ndarray,
    r_frac: np.ndarray,
    f_Ga_fn,
    f_As_fn,
    species: np.ndarray,
    biso: np.ndarray,
    a: float,
    chunk_size: int = 32
) -> np.ndarray:
    """
    Calculate the average structure factor <F>(hkl).
    
    The average structure has each site occupied by the average species.
    For C1: occ_Ga = 1723/4096, occ_As = 2373/4096.
    
    <F>(hkl) = occ_Ga * F_Ga(hkl) + occ_As * F_As(hkl)
    
    where F_Ga(hkl) = sum_Ga_sites f_Ga(s) * exp(-Biso*s^2) * exp(2pi*i*h.r)
    and F_As(hkl) = sum_As_sites f_As(s) * exp(-Biso*s^2) * exp(2pi*i*h.r)
    
    This is the structure factor of the "average crystal" where each site
    is occupied by the average species with fractional occupancies.
    """
    M = hkl.shape[0]
    F_avg = np.zeros(M, dtype=complex)
    
    N = len(species)
    occ_Ga = np.sum(species == 'GA') / N
    occ_As = np.sum(species == 'AS') / N
    
    ga_mask = (species == 'GA')
    r_Ga = r_frac[ga_mask]
    biso_Ga = biso[ga_mask]
    r_As = r_frac[~ga_mask]
    biso_As = biso[~ga_mask]
    
    for start in range(0, M, chunk_size):
        end = min(start + chunk_size, M)
        h_chunk = hkl[start:end]  # (C, 3)
        
        hkl_mag = np.linalg.norm(h_chunk, axis=1)  # (C,)
        s_chunk = hkl_mag / (2.0 * a)  # (C,)
        
        f_Ga_chunk = f_Ga_fn(s_chunk)  # (C,)
        f_As_chunk = f_As_fn(s_chunk)  # (C,)
        
        s2_chunk = s_chunk**2  # (C,)
        dw_Ga = np.exp(-biso_Ga * s2_chunk[:, np.newaxis])
        dw_As = np.exp(-biso_As * s2_chunk[:, np.newaxis])
        
        dot_Ga = h_chunk @ r_Ga.T
        F_Ga_chunk = f_Ga_chunk * np.sum(dw_Ga * np.exp(1j * 2 * np.pi * dot_Ga), axis=1)
        
        dot_As = h_chunk @ r_As.T
        F_As_chunk = f_As_chunk * np.sum(dw_As * np.exp(1j * 2 * np.pi * dot_As), axis=1)
        
        # <F>(hkl) = occ_Ga * F_Ga(hkl) + occ_As * F_As(hkl)
        F_avg[start:end] = occ_Ga * F_Ga_chunk + occ_As * F_As_chunk
    
    return F_avg


def build_hkl_grid(
    nx: int, ny: int, nz: int,
    hmin: float, step: float
) -> np.ndarray:
    """
    Build a 3D hkl grid.
    
    Args:
        nx, ny, nz: grid dimensions
        hmin: minimum hkl value (e.g., -4.0)
        step: step size (e.g., 0.125)
    
    Returns:
        hkl_grid: (nx, ny, nz, 3) array
    """
    h_vals = np.arange(nx) * step + hmin
    k_vals = np.arange(ny) * step + hmin
    l_vals = np.arange(nz) * step + hmin
    
    H, K, L = np.meshgrid(h_vals, k_vals, l_vals, indexing='ij')
    return np.stack([H, K, L], axis=-1)


# ---------------------------------------------------------------------------
# Comparison metrics
# ---------------------------------------------------------------------------

def compute_metrics(independent: np.ndarray, discus: np.ndarray) -> dict:
    """
    Compute comparison metrics between independent and DISCUS values.
    """
    diff = np.abs(independent - discus)
    l2_diff = np.sqrt(np.sum(diff**2))
    l2_discus = np.sqrt(np.sum(discus**2))
    rel_l2 = l2_diff / l2_discus if l2_discus != 0 else float('inf')
    
    if independent.std() > 0 and discus.std() > 0:
        pearson = np.corrcoef(independent.flatten(), discus.flatten())[0, 1]
    else:
        pearson = float('nan')
    
    # Scale ratio (mean of independent/discus where discus is nonzero)
    nonzero = np.abs(discus) > 1e-10
    if nonzero.any():
        scale_ratio = np.mean(independent[nonzero] / discus[nonzero])
    else:
        scale_ratio = float('nan')
    
    max_idx = np.unravel_index(np.argmax(diff), diff.shape)
    
    return {
        "max_abs_diff": float(diff.max()),
        "mean_abs_diff": float(diff.mean()),
        "rel_l2": float(rel_l2),
        "pearson": float(pearson),
        "scale_ratio": float(scale_ratio),
        "independent_max": float(independent.max()),
        "discus_max": float(discus.max()),
        "independent_mean": float(independent.mean()),
        "discus_mean": float(discus.mean()),
        "largest_residual_index": [int(x) for x in max_idx],
    }


# ---------------------------------------------------------------------------
# Main benchmark
# ---------------------------------------------------------------------------

def run_full_benchmark(
    stru_path: str,
    total_h5: str,
    diffuse_h5: str,
    output_json: str = None
) -> dict:
    """
    Run the full benchmark (total + diffuse) using IT92 form factors.
    """
    print(f"\n{'='*60}")
    print(f"INDEPENDENT STRUCTURE-FACTOR BENCHMARK (v2 — CORRECTED)")
    print(f"{'='*60}")
    
    # Read structure
    species, r_frac, biso = read_stru(stru_path)
    N = len(species)
    n_Ga = np.sum(species == 'GA')
    n_As = np.sum(species == 'AS')
    print(f"Atoms: {N} ({n_Ga} GA, {n_As} AS)")
    print(f"Coordinates: base-cell fractional units (NOT Cartesian)")
    print(f"  r_frac range: [{r_frac.min():.4f}, {r_frac.max():.4f}]")
    print(f"  Biso range: [{biso.min():.4f}, {biso.max():.4f}] A^2")
    
    # Read DISCUS metadata
    with h5py.File(total_h5, "r") as h:
        data = h["entry"]["data"]
        a = float(data["unit_cell_lengths"][0])
        nx, ny, nz = data["data_dimension"][()]
        hmin = float(data["data_corner"][0])
        step = float(data["data_increment_vector"][0, 0])
        discus_total = data["data_values"][:]
    
    with h5py.File(diffuse_h5, "r") as h:
        discus_diffuse = h["entry"]["data"]["data_values"][:]
    
    print(f"Unit cell: a = {a:.6f} A")
    print(f"Grid: {nx}x{ny}x{nz}, hmin={hmin}, step={step}")
    
    # Build hkl grid
    hkl_grid = build_hkl_grid(nx, ny, nz, hmin, step)
    hkl_flat = hkl_grid.reshape(-1, 3)
    
    # Form factor functions (IT92)
    f_Ga_fn = f_xray_Ga
    f_As_fn = f_xray_As
    
    # Verify f(0) values
    f_Ga_0 = f_Ga_fn(np.array([0.0]))[0]
    f_As_0 = f_As_fn(np.array([0.0]))[0]
    print(f"Form factors (IT92): f_Ga(0)={f_Ga_0:.4f}, f_As(0)={f_As_0:.4f}")
    
    # Calculate F(hkl) for all grid points
    print(f"Calculating F(hkl) for {len(hkl_flat)} grid points...")
    F_all = calculate_structure_factor(
        hkl_flat, r_frac, f_Ga_fn, f_As_fn, species, biso, a, chunk_size=32
    )
    
    # Total intensity
    I_total = np.abs(F_all)**2
    I_total = I_total.reshape(nx, ny, nz)
    print(f"  Total: max={I_total.max():.4e}, min={I_total.min():.4e}")
    
    # Average structure factor (for amplitude-based diffuse)
    print("Calculating average structure factor <F>(hkl)...")
    F_avg = calculate_average_structure_factor(
        hkl_flat, r_frac, f_Ga_fn, f_As_fn, species, biso, a, chunk_size=32
    )
    
    # Amplitude-based diffuse: |F(hkl) - <F>(hkl)|^2
    I_diff_amplitude = np.abs(F_all - F_avg)**2
    I_diff_amplitude = I_diff_amplitude.reshape(nx, ny, nz)
    print(f"  Diffuse (amplitude): max={I_diff_amplitude.max():.4e}, min={I_diff_amplitude.min():.4e}")
    
    # Empirical mask-based diffuse (for comparison with observed sampling)
    # On the sampled 65^3 grid, DISCUS shows diffuse=0 at integer hkl.
    # This reproduces the observed sampling, NOT a general physical model.
    I_diff_mask = I_total.copy()
    int_indices = np.arange(0, 65, 8)  # 0, 8, 16, 24, 32, 40, 48, 56, 64
    for i in int_indices:
        for j in int_indices:
            for k in int_indices:
                I_diff_mask[i, j, k] = 0.0
    print(f"  Diffuse (mask): max={I_diff_mask.max():.4e}, min={I_diff_mask.min():.4e}")
    
    # Compare
    results = {}
    for name, ind, disc in [
        ("total", I_total, discus_total),
        ("diffuse_amplitude", I_diff_amplitude, discus_diffuse),
        ("diffuse_mask", I_diff_mask, discus_diffuse),
    ]:
        metrics = compute_metrics(ind, disc)
        hkl_at_max = hkl_grid[tuple(metrics["largest_residual_index"])]
        
        discus_max_idx = np.unravel_index(np.argmax(disc), disc.shape)
        discus_peak_hkl = hkl_grid[discus_max_idx]
        discus_peak_val = disc[discus_max_idx]
        ind_peak_val = ind[discus_max_idx]
        
        metrics["largest_residual_hkl"] = [float(x) for x in hkl_at_max]
        metrics["discus_peak_hkl"] = [float(x) for x in discus_peak_hkl]
        metrics["discus_peak_value"] = float(discus_peak_val)
        metrics["independent_at_discus_peak"] = float(ind_peak_val)
        
        results[name] = metrics
        
        print(f"  {name}: rel_L2={metrics['rel_l2']:.6e}, pearson={metrics['pearson']:.8f}, "
              f"max_diff={metrics['max_abs_diff']:.4e} at hkl={hkl_at_max}")
        print(f"    DISCUS peak: {discus_peak_val:.4e} at hkl={discus_peak_hkl}, "
              f"independent at same point: {ind_peak_val:.4e}")
    
    # (0,0,0) comparison
    origin_idx = (32, 32, 32)
    results["origin_comparison"] = {
        "discus": float(discus_total[origin_idx]),
        "independent": float(I_total[origin_idx]),
        "ratio": float(I_total[origin_idx] / discus_total[origin_idx]) if discus_total[origin_idx] != 0 else float('nan'),
    }
    print(f"\n  (0,0,0): DISCUS={discus_total[origin_idx]:.4e}, "
          f"independent={I_total[origin_idx]:.4e}, "
          f"ratio={results['origin_comparison']['ratio']:.6f}")
    
    # Example hkl point
    example_idx = (31, 32, 32)  # hkl=(-0.125, 0, 0)
    results["example_hkl_(-0.125,0,0)"] = {
        "discus": float(discus_total[example_idx]),
        "independent": float(I_total[example_idx]),
        "ratio": float(I_total[example_idx] / discus_total[example_idx]) if discus_total[example_idx] != 0 else float('nan'),
    }
    print(f"  (-0.125,0,0): DISCUS={discus_total[example_idx]:.4e}, "
          f"independent={I_total[example_idx]:.4e}, "
          f"ratio={results['example_hkl_(-0.125,0,0)']['ratio']:.6f}")
    
    # Observed total/diffuse relationship
    actual_noninteger = np.ones(discus_diffuse.shape, dtype=bool)
    actual_noninteger[::8, ::8, ::8] = False
    results["observed_noninteger_total_diffuse_rel_L2"] = float(
        np.linalg.norm((discus_total - discus_diffuse)[actual_noninteger]) /
        np.linalg.norm(discus_total[actual_noninteger])
    )
    results["observed_max_integer_diffuse"] = float(discus_diffuse[::8, ::8, ::8].max())
    
    if output_json:
        with open(output_json, "w") as f:
            json.dump(results, f, indent=2)
        print(f"\nResults written to {output_json}")
    
    return results


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Independent structure-factor benchmark (v2)")
    parser.add_argument("--stru", required=True, help="Path to .stru file")
    parser.add_argument("--total", required=True, help="Path to DISCUS total HDF5")
    parser.add_argument("--diffuse", required=True, help="Path to DISCUS diffuse HDF5")
    parser.add_argument("--output", default=None, help="Output JSON path")
    
    args = parser.parse_args()
    
    results = run_full_benchmark(
        args.stru, args.total, args.diffuse,
        output_json=args.output
    )
